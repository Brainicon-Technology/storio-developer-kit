# @storio/template-sdk

Standardized Data Fetching SDK for Storio CMS Templates.

Effortlessly fetch backend V2 API data with automatic multi-tenant routing, built-in Next.js caching, and 100% TypeScript type safety.

---

## Quick Start for Template Developers

If you are building or editing a Storio template (e.g. `zenova`, `cpsc`, `emerald`, `ikigai`), you do not need to configure anything special!

### 1. Import the SDK
In any server component or page file, import `storio`:

```typescript
import { storio, StorioSettingsResponse, StorioNotice } from '@storio/template-sdk';
```

### 2. Fetch Data with 1-Line Calls

```typescript
// Fetch site title, logo, social links, and navigation
const layout = await storio.getLayout();

// Fetch public notice board items
const notices = await storio.getNotices();

// Fetch hero carousel slides
const heroSlides = await storio.getHeroSlides();
```

---

## Code Examples

### Example 1: Rendering Header Logo & Site Title
```typescript
import { storio } from '@storio/template-sdk';

export default async function Header() {
  const settings = await storio.getSettings();

  return (
    <header>
      {settings?.logo_url && <img src={settings.logo_url} alt="Logo" />}
      <h1>{settings?.site_title || "My Storio Site"}</h1>
    </header>
  );
}
```

### Example 2: Rendering Notice Board Items
```typescript
import { storio } from '@storio/template-sdk';

export default async function NoticeList() {
  const notices = await storio.getNotices();

  return (
    <ul>
      {notices?.map((notice) => (
        <li key={notice.id}>
          <a href={`/notices/${notice.id}`}>{notice.title}</a>
          <span>{notice.published_date}</span>
        </li>
      ))}
    </ul>
  );
}
```

---

## Complete SDK Method Reference

All methods automatically handle multi-tenant routing headers (`x-tenant-host`) and cache responses for 60 seconds (`revalidate: 60`).

| SDK Method | Returns | Description |
| :--- | :--- | :--- |
| `storio.getSettings()` | `Promise<StorioSettingsResponse \| null>` | Site title, tagline, logo, favicon, contact email, social links |
| `storio.getCustomization()` | `Promise<StorioCustomizationResponse \| null>` | Template color schemes, typography, and feature toggles |
| `storio.getNavigation()` | `Promise<StorioNavigationResponse \| null>` | Header navbar links array |
| `storio.getLayout()` | `Promise<StorioLayoutResponse \| null>` | Combined settings, customization, and navigation layout |
| `storio.getHeroSlides()` | `Promise<StorioHeroSlide[] \| null>` | Home page hero banner carousel slides |
| `storio.getNotices()` | `Promise<StorioNotice[] \| null>` | Public notice board announcements |
| `storio.getNoticeDetail(id)` | `Promise<StorioNotice \| null>` | Single notice announcement details |
| `storio.getBlogs()` | `Promise<StorioBlogPost[] \| null>` | Published blog posts list |
| `storio.getBlogDetail(slug)` | `Promise<StorioBlogPost \| null>` | Single blog article details |
| `storio.getStaff()` | `Promise<StorioStaffMember[] \| null>` | School/organization staff list |
| `storio.getTeam()` | `Promise<StorioStaffMember[] \| null>` | Leadership team members list |
| `storio.getGallery()` | `Promise<StorioGalleryItem[] \| null>` | Photo gallery items |
| `storio.getAlbums()` | `Promise<StorioAlbum[] \| null>` | Photo albums with nested images |
| `storio.getPageBySlug(slug)` | `Promise<StorioCustomPage \| null>` | Dynamic CMS custom page |

---

## How to Edit & Re-pack the SDK (For SDK Maintainers)

If you need to edit the SDK source code (`packages/template-sdk/src/index.ts`):

1. **Compile the TypeScript:**
   ```bash
   cd packages/template-sdk
   npm run build
   ```
2. **Pack the Local Tarball:**
   ```bash
   npm pack
   ```
3. **Re-install in Template Folders:**
   ```bash
   cd ../../zenova
   npm install
   ```

---

## Updating After Git Pull

If a team member pulled updated SDK code from Git (`git pull origin main`), run:

```bash
# 1. Re-build and pack the SDK
cd packages/template-sdk
npm run build
npm pack

# 2. Re-install in your working template folder
cd ../../zenova   # (or cpsc, emerald, ikigai)
npm install
```
