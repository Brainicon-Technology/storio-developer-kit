declare var process: any;

export interface StorioFetchOptions extends RequestInit {
  tenantHost?: string;
  backendBaseUrl?: string;
  next?: { revalidate?: number | false; tags?: string[] };
}

// Exported TypeScript Response Interfaces for V2 Template APIs
export interface StorioSocialLink {
  platform: string;
  url: string;
}

export interface StorioSettingsResponse {
  site_title?: string;
  site_tagline?: string;
  logo_url?: string;
  favicon_url?: string;
  contact_email?: string;
  phone_number?: string;
  social_links?: StorioSocialLink[];
  mailing_address?: string;
  hcaptcha_site_key?: string;
}

export interface StorioCustomizationResponse {
  config: Record<string, string | number | boolean | unknown>;
}

export interface StorioNavigationItem {
  id?: string | number;
  label: string;
  url: string;
  target?: string;
  children?: StorioNavigationItem[];
}

export interface StorioNavigationResponse {
  items: StorioNavigationItem[];
}

export interface StorioLayoutResponse {
  settings: StorioSettingsResponse;
  customization: StorioCustomizationResponse;
  navigation: StorioNavigationResponse;
}

export interface StorioHeroSlide {
  id: number;
  title?: string;
  subtitle?: string;
  image_url?: string;
  button_text?: string;
  button_url?: string;
  order?: number;
}

export interface StorioNotice {
  id: number;
  title: string;
  slug?: string;
  content?: string;
  published_date?: string;
  is_urgent?: boolean;
  attachment_url?: string;
}

export interface StorioBlogPost {
  id: number;
  title: string;
  slug: string;
  summary?: string;
  content?: string;
  featured_image_url?: string;
  category_name?: string;
  published_at?: string;
}

export interface StorioStaffMember {
  id: number;
  name: string;
  designation?: string;
  department?: string;
  photo_url?: string;
  email?: string;
  phone_number?: string;
  bio?: string;
}

export interface StorioGalleryItem {
  id: number;
  title?: string;
  image_url: string;
  caption?: string;
}

export interface StorioAlbum {
  id: number;
  title: string;
  cover_image_url?: string;
  images?: StorioGalleryItem[];
}

export interface StorioCustomPage {
  id: number;
  title: string;
  slug: string;
  content: string | Record<string, unknown>[];
  meta_title?: string;
  meta_description?: string;
  featured_image?: string;
}

// Storio SDK Core Client Class
export class StorioSDK {
  private backendBaseUrl: string;

  constructor(
    backendBaseUrl: string = process.env.BACKEND_INTERNAL_URL ||
      process.env.NEXT_PUBLIC_API_URL ||
      process.env.NEXT_PUBLIC_API_BASE_URL ||
      'http://127.0.0.1:8000'
  ) {
    this.backendBaseUrl = backendBaseUrl;
  }

  // Universal fetch wrapper that automatically appends tenant headers
  
  public async apiFetch<T>(endpoint: string, options: StorioFetchOptions = {}): Promise<T | null> {
    const { tenantHost, backendBaseUrl, ...fetchOptions } = options;
    const base = backendBaseUrl || this.backendBaseUrl;

    // Ensure we don't double slash
    const url = `${base.replace(/\/$/, '')}/${endpoint.replace(/^\//, '')}`;

    const headers = new Headers(fetchOptions.headers);
    headers.set('Content-Type', 'application/json');

    if (tenantHost) {
      headers.set('x-tenant-host', tenantHost);
      headers.set('Host', tenantHost);
    }

    try {
      const res = await fetch(url, { ...fetchOptions, headers });
      if (!res.ok) {
        console.warn(`[Storio SDK] Error fetching ${endpoint}: HTTP ${res.status}`);
        return null as unknown as T;
      }
      const contentType = res.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return (await res.json()) as T;
      }
      console.warn(`[Storio SDK] Expected JSON but received non-JSON response from ${endpoint}`);
      return null as unknown as T;
    } catch (err) {
      console.warn(`[Storio SDK] Network error fetching ${endpoint}:`, err);
      return null as unknown as T;
    }
  }

  private parseOptions(tenantHostOrOptions?: string | StorioFetchOptions): StorioFetchOptions {
    if (typeof tenantHostOrOptions === 'string') {
      return { tenantHost: tenantHostOrOptions, next: { revalidate: 60 } };
    }
    return { next: { revalidate: 60 }, ...tenantHostOrOptions };
  }

  // V2 Core Template APIs (Strongly Typed)
  public async getSettings(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioSettingsResponse | null> {
    return this.apiFetch<StorioSettingsResponse>('/api/v2/template/settings/', this.parseOptions(tenantHostOrOptions));
  }

  public async getCustomization(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioCustomizationResponse | null> {
    return this.apiFetch<StorioCustomizationResponse>('/api/v2/template/customization/', this.parseOptions(tenantHostOrOptions));
  }

  public async getNavigation(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioNavigationResponse | null> {
    return this.apiFetch<StorioNavigationResponse>('/api/v2/template/navigation/', this.parseOptions(tenantHostOrOptions));
  }

  public async getLayout(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioLayoutResponse | null> {
    return this.apiFetch<StorioLayoutResponse>('/api/v2/template/layout/', this.parseOptions(tenantHostOrOptions));
  }

  // V2 Content Template APIs (Strongly Typed)
  public async getHeroSlides(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioHeroSlide[] | null> {
    return this.apiFetch<StorioHeroSlide[]>('/api/v2/template/hero-slides/', this.parseOptions(tenantHostOrOptions));
  }

  public async getNotices(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioNotice[] | null> {
    return this.apiFetch<StorioNotice[]>('/api/v2/template/notices/', this.parseOptions(tenantHostOrOptions));
  }

  public async getNoticeDetail(
    id: number | string,
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioNotice | null> {
    return this.apiFetch<StorioNotice>(`/api/v2/template/notices/${id}/`, this.parseOptions(tenantHostOrOptions));
  }

  public async getBlogs(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioBlogPost[] | null> {
    return this.apiFetch<StorioBlogPost[]>('/api/v2/template/blogs/', this.parseOptions(tenantHostOrOptions));
  }

  public async getBlogDetail(
    slug: string,
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioBlogPost | null> {
    return this.apiFetch<StorioBlogPost>(`/api/v2/template/blogs/${slug}/`, this.parseOptions(tenantHostOrOptions));
  }

  public async getStaff(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioStaffMember[] | null> {
    return this.apiFetch<StorioStaffMember[]>('/api/v2/template/staff/', this.parseOptions(tenantHostOrOptions));
  }

  public async getTeam(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioStaffMember[] | null> {
    return this.apiFetch<StorioStaffMember[]>('/api/v2/template/team/', this.parseOptions(tenantHostOrOptions));
  }

  public async getGallery(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioGalleryItem[] | null> {
    return this.apiFetch<StorioGalleryItem[]>('/api/v2/template/gallery/', this.parseOptions(tenantHostOrOptions));
  }

  public async getAlbums(
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioAlbum[] | null> {
    return this.apiFetch<StorioAlbum[]>('/api/v2/template/albums/', this.parseOptions(tenantHostOrOptions));
  }

  public async getPageBySlug(
    slug: string,
    tenantHostOrOptions?: string | StorioFetchOptions
  ): Promise<StorioCustomPage | null> {
    return this.apiFetch<StorioCustomPage>(`/api/v2/template/pages/by-slug/${slug}/`, this.parseOptions(tenantHostOrOptions));
  }
}

// Export a default singleton instance for ease of use
export const storio = new StorioSDK();
