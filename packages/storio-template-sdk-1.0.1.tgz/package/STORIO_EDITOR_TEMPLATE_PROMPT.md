# Make a Storio template editable from the Storio dashboard

## For the developer (read this first, 1 minute)

This file makes a Storio template editable in **Storio dashboard → Settings → Template Customization**: school admins click a text, image or icon in the preview and change it, including its style (colour, size, spacing, font...), plus each page's SEO.

It is self-contained. It needs **no library, no download and no other repository**: the editor code your template needs is written out in full at the end of this file (Appendix A), and Claude Code copies it into your template.

How to use it:

1. Commit or stash your work in the template repository.
2. Copy this file into the **root of the template repository** (next to `package.json`).
3. Open Claude Code in that folder and say:
   **"Read STORIO_EDITOR_TEMPLATE_PROMPT.md completely and follow it exactly."**
   (Do not paste it into the chat: it is long. Let Claude Code read the file.)
4. When it is done, review its report and the diff, test it (STEP 9), then delete this file from the template and commit.

The Storio platform you test against must include the Storio editor work (storio-cms branch `elements-editor` or later: `/api/cms/`, the dashboard editor, `editorPages` validation).

---

## Instructions for Claude Code

You are converting this repository, a **Storio template**, so that school admins can edit its static content from the Storio dashboard. Read this whole file before you change anything. Follow it exactly. Where it gives code, use that code exactly (only the parts written in `<ANGLE_BRACKETS>` change). Never invent another approach.

### CONTEXT

- Storio is a multi-tenant platform for school websites. This repository is ONE template: a Next.js (App Router) site that the Storio gateway serves on each school's domain. The same build serves every school; the school is known from the request's host.
- School admins edit the template in the Storio dashboard (another repository you do not have). The dashboard shows this template in a preview iframe on the school's domain, and talks to it with `window.postMessage` messages. Edits are saved by the Storio backend at `/api/cms/` on the school's domain, per school.
- What you build in this repository:
  1. **The editor kit** (`<KIT_DIR>`, Appendix A): 25 small TypeScript files that provide `<CmsProvider>`, `<CmsSection>`, `<CmsField>`, `<CmsIcon>`, `usePageContent`, `getAllPageContent`, `getPageMetadata` and the `/api/cms/` client. It is a fixed protocol shared with the Storio dashboard and backend. Copy it exactly; never edit it (except as STEP 2 allows).
  2. **The wiring** (STEP 3): the config built from the manifest, the providers in the root layout, the Theme settings pencil and a sync/check script.
  3. **The conversion** (STEP 4 and 5): every static text, image and icon of every page is moved into a JSON file of defaults and rendered from the page content, wrapped in `<CmsField>`, inside a `<CmsSection>`. Visitors see exactly the same site; the editor preview shows pencils.
  4. **The manifest entries** (`editorPages` in `public/storio.template.json`): the list of editable pages, sections and defaults. The dashboard builds its editor from it, and the backend accepts saves only for what it lists.
- How content flows:
  - Default content lives in `CONFIG_DIR/content/<page key>.json` and is copied into the manifest (`editorPages[].defaults`) by `npm run editor:sync`.
  - A school's saved content comes from `/api/cms/records?page=<page key>`. On the server, `<CmsProviders>` loads it for the request's school, so the first HTML already contains the edited text. In the editor preview, `<CmsProvider>` also receives unsaved drafts by `postMessage` and re-renders immediately.
  - A saved section **replaces** that section's defaults as a whole; the `use<Page>Text` helper (STEP 5) fills missing fields from the defaults.
  - Field styles (the editor's Style tab) are saved as a `_styles` record per page and applied by `<CmsField>` automatically: no code for them.
- Texts that come from the template's **customization** (Theme settings; values the template reads from `/api/v2/template/customization/`, often through a `LiveText` component or `customization?.field_id || 'fallback'`) already have an editor: Theme settings. They are NOT moved into page content; they get a `<ThemeField>` pencil that opens that Theme settings field.
- Data from the Storio API (hero slides, notices, events, staff, gallery, institution profile, school name, logo, contact details...) is the school's own data, edited on other dashboard pages. It gets **no pencil** (except the record fields of STEP 7).

### SAFETY RULES (most important)

1. Run `git status` first. If there are uncommitted changes, stop and ask me whether to commit them. Then create the branch `storio-editor` and do all work there.
2. **Visitors must see exactly the same website as before**: same texts (character for character, including spaces, punctuation and entities), same layout, same classes, same images, same data, same behaviour (links, animations, conditions). Never delete, rename, reorder or rewrite code you were not asked to change. Never "clean up", reformat or modernise code.
3. **No library.** Do not install `@brainicon/storio-elements-editor` or any other package for the editor; everything comes from Appendix A. If the project already has that package (an older conversion), follow STEP 2.4 to replace it.
4. Do NOT create an admin page, an `app/api/cms` route, a login form, an auth gate, file storage or a `.cms/` folder. Storio provides all of that.
5. Do NOT change: the Storio SDK calls and data fetchers; how the template reads its customization (`/api/v2/template/customization/`, customConfig, `LiveText`); the postMessage code of the classic customizer (`THEME_UPDATE`, `SET_INSPECTOR_MODE`, `CUSTOMIZER_INSPECT_CLICK`, `data-customizer-field` attributes); the manifest's `customization` and `navigation` fields; translation/i18n files; middleware logic (except STEP 3.8).
6. Move **only static, hard-coded** content into page content: text written literally in JSX, literal `alt`/`placeholder`/`aria-label`/`title` attributes, fixed image paths, fixed lucide icon components, and static arrays/objects of such content defined in the code. Never move: texts from customization, the Storio API, props, state, translations, dates, numbers computed in code, URLs/hrefs, class names, or anything used in logic.
7. In scope: every page's static texts, images, icons, field styles and SEO (STEP 4-5), the header and footer (STEP 6), notice/blog/event detail pages (STEP 7). Out of scope: translations, other dynamic routes (`[slug]`, `[id]`, `[...slug]` pages other than STEP 7), rich-text bodies of records.
8. After every page run `npx tsc --noEmit` and the visible-text comparison (STEP 5.1 and 5.12); at the end of every page also run `npm run build`. Stop the dev server before `npm run build` (both write to `.next`; running both corrupts it) and start it again afterwards. If the build fails inside `.next/` itself, delete the `.next` folder and build again. If a check fails, fix the cause or undo that page's changes before you continue.
9. Never edit anything inside `node_modules`.
10. Ask me only for things you cannot find out yourself. Do not stop between pages: continue until every page is converted or reported as skipped.
11. Do not commit. I will review first.

### INPUTS (find them yourself, write them down)

- **TEMPLATE_ID**: the `"id"` in `public/storio.template.json` (for example `template-7-zenova`).
- **APP_DIR**: `app/` or `src/app/`.
- **CONFIG_DIR**: the project root when the app is in `app/`; `src/` when it is in `src/app/`.
- **KIT_DIR**: `CONFIG_DIR/lib/storio-editor` (for example `src/lib/storio-editor`).
- **ALIAS**: the import alias in `tsconfig.json` → `compilerOptions.paths` (usually `@/*` → `./src/*` or `./*`). You may use it or relative imports in the files you convert; the files of this prompt use relative imports so they work without it.
- **NEXT_VERSION**: the `next` version in `package.json`.
- **TENANT_HOST**: how this template finds the school's host on the server. Search the fetchers for `getTenantHost`, `getTenantContext`, `x-tenant-host`, `x-forwarded-host`, `headers()`. You reuse that helper, you do not write new logic.
- **PAGES**: every `page.tsx`/`page.jsx`/`page.js` under APP_DIR that visitors open, except dynamic routes, API routes and error/not-found pages. For each: its route ("/", "/about"...) and the components it renders.
- **RECORD_PAGES**: the detail pages of notices, blog posts and events (for example `app/notice/[id]`, `app/blog/[slug]`, `app/events/[slug]`). Confirm in the code which Storio data each reads and whether the URL holds the notice's id or the post's/event's slug.
- **CUSTOMIZATION_FIELDS**: the field ids in the manifest's `customization` groups (for example `content: [{ "id": "about_section_title", ... }]`) and how the template renders them.

### NAMING RULES (Storio refuses anything else)

- **Page key**: `<TEMPLATE_ID>-<name>`, lowercase, letters/digits/`-`: `<TEMPLATE_ID>-home` for `/`, `<TEMPLATE_ID>-about` for `/about`, `<TEMPLATE_ID>-about-institution` for `/about/institution`. Record pages: `<TEMPLATE_ID>-<name>-detail`.
- **Section key**: letters, digits, `_` or `-`, starting with a letter, meaningful (`hero`, `about`, `features`, `cta`...), unique within the page. **Never** `seo` (reserved for SEO, STEP 5.10), `navigation`, or the name of a `customization` group of the manifest (`colors`, `typography`, `layout`, `content`...). Never add `"global": true` to a page. (Either one stops every Theme settings pencil from working; the sync script refuses both.)
- **Field names** decide which control the editor shows. Use camelCase:
  - plain text: `title`, `subtitle`, `description`, `buttonText`, `linkText`, `label`, `badgeText`, `titleStart`, `titleHighlight`...
    A text field must NOT start with `icon`, must NOT end with `icon`, `color`/`colour` or `font`, must not be `id`, and must not contain `image`, `img`, `logo`, `photo`, `avatar`, `banner`, `cover`, `thumbnail`, `preview`, `picture`, `src` or `favicon` unless it ends with `Alt`, `Label`, `Title`, `Text` or `Description` (for example `imageAlt`, `logoTitle`).
  - image (image picker and upload): ends with `image` or `Image` (`image`, `heroImage`, `backgroundImage`), or `logo`/`photo`. Never ends with `icon`.
  - icon (icon picker): ends with `icon` or `Icon` (`icon`, `featureIcon`). Its value is a lucide icon name such as `"GraduationCap"`.
  - repeated items: an array of objects under a plural name (`features`, `steps`, `cards`), each object using the rules above.

### STEP 1. Check the project

- Next.js **App Router** (an `app/` or `src/app/` folder with `layout`/`page` files) with React 18 or later. If the template uses only the Pages Router, stop and tell me.
- TypeScript: the kit is TypeScript. If `typescript` is not in `devDependencies`, run `npm install -D typescript @types/react @types/node` (a JavaScript template can keep its `.js`/`.jsx` files; Next.js compiles the `.ts` files next to them). `tsconfig.json` must have `"resolveJsonModule": true` (Next.js sets it by default).
- The kit needs only `react`, `react-dom` and `next`. `lucide-react` is needed only if the template uses lucide icons (STEP 5.9); it is usually already installed.
- Write down the INPUTS and the list of PAGES with their components.

### STEP 2. Create the editor kit

1. Create the folder `<KIT_DIR>` and in it the 25 files of **Appendix A**, at exactly the paths given, with exactly the content given: copy each file character for character, including comments and the `'use client';` lines. Do not reformat, rename, translate, "improve" or shorten anything. The files:
- `<KIT_DIR>/index.ts`
- `<KIT_DIR>/site.ts`
- `<KIT_DIR>/server.ts`
- `<KIT_DIR>/core/types.ts`
- `<KIT_DIR>/core/defineCms.ts`
- `<KIT_DIR>/core/merge.ts`
- `<KIT_DIR>/core/messages.ts`
- `<KIT_DIR>/core/paths.ts`
- `<KIT_DIR>/core/styles.ts`
- `<KIT_DIR>/core/theme.ts`
- `<KIT_DIR>/core/collections.ts`
- `<KIT_DIR>/adapters/rest.ts`
- `<KIT_DIR>/adapters/django.ts`
- `<KIT_DIR>/server/getPageContent.ts`
- `<KIT_DIR>/server/isCmsPreviewRequest.ts`
- `<KIT_DIR>/site/PencilIcon.tsx`
- `<KIT_DIR>/site/preview.ts`
- `<KIT_DIR>/site/sectionContext.ts`
- `<KIT_DIR>/site/fieldStyles.ts`
- `<KIT_DIR>/site/itemDrafts.ts`
- `<KIT_DIR>/site/CmsProvider.tsx`
- `<KIT_DIR>/site/CmsSection.tsx`
- `<KIT_DIR>/site/CmsField.tsx`
- `<KIT_DIR>/site/CmsIcon.tsx`
- `<KIT_DIR>/site/CmsThemeStyle.tsx`
2. The kit uses only relative imports between its own files, `react`, `react-dom` and `next`. The only change you may make: if the project's lint or type check rejects something in the kit only because of a project-specific rule, add the folder to that tool's ignore list (for example `ignores: ['<KIT_DIR>/**']` in `eslint.config.*`). Never change the kit's code.
3. Check: `npx tsc --noEmit` passes, and every file of the list exists (count them).
4. Only if the project already uses `@brainicon/storio-elements-editor` (an older conversion): replace every import of it:
   - `'@brainicon/storio-elements-editor'` and `'@brainicon/storio-elements-editor/adapters'` → the kit folder (`<KIT_DIR>`, for example `'@/lib/storio-editor'`)
   - `'@brainicon/storio-elements-editor/site'` → `<KIT_DIR>/site`
   - `'@brainicon/storio-elements-editor/next'` → `<KIT_DIR>/server`
   then remove the `@source ".../node_modules/@brainicon/storio-elements-editor/dist";` line from the global CSS, run `npm uninstall @brainicon/storio-elements-editor`, and make sure nothing mentions `@brainicon/storio-elements-editor` any more (`grep -rn "storio-elements-editor" --include=*.ts --include=*.tsx --include=*.js --include=*.jsx --include=*.css --include=*.json . | grep -v node_modules`). Then replace the existing wiring files with the ones of STEP 3 (keep their page lists and section code).

### STEP 3. Create the wiring

Create these files with exactly this content. Change only what is written in `<ANGLE_BRACKETS>` and the relative paths noted in the comments.

**3.1 The config.** It builds the pages from the manifest, so the template and the dashboard always describe the same pages. (If CONFIG_DIR is `src/`, the manifest import is `'../public/storio.template.json'`.)

#### `CONFIG_DIR/cms.config.ts`

````ts
import { defineCms, djangoAdapter } from './lib/storio-editor';
// The editable pages live in the manifest ("editorPages"), the same list the Storio dashboard
// reads, so the template and the editor can never disagree. Edit content/<page>.json, then run
// `npm run editor:sync`. CONFIG_DIR = project root: './public/...'; CONFIG_DIR = src/: '../public/...'.
import manifest from './public/storio.template.json';
// Generated from the manifest's "editorIcons" by scripts/storio-editor-sync.mjs: the icons the
// editor's picker offers and <CmsIcon> draws.
import { cmsIcons } from './lib/cms-icons.generated';

type EditorPage = {
  key: string;
  title: string;
  route: string;
  global?: boolean;
  collection?: string;
  parent?: string;
  sections: { key: string; label: string }[];
  defaults?: Record<string, unknown>;
};

const editorPages = ((manifest as unknown as { editorPages?: EditorPage[] }).editorPages ?? []).map((page) => ({
  key: page.key,
  title: page.title,
  route: page.route,
  global: page.global || undefined,
  collection: page.collection,
  parent: page.parent,
  sections: page.sections,
  defaults: page.defaults ?? {},
}));

// Inside the Storio editor preview the admin is signed in to the dashboard on the same domain:
// send their token so drafts show. Visitors have no token and get published content only.
function previewHeaders(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  try {
    const token = window.localStorage.getItem('accessToken');
    return token ? { Authorization: `Bearer ${token}` } : {};
  } catch {
    return {};
  }
}

export const cms = defineCms({
  title: 'Template content',
  // In the browser, /api/cms on the school's domain reaches that school's content (Storio gateway).
  adapter: djangoAdapter({ baseUrl: '/api/cms', credentials: 'same-origin', headers: previewHeaders, media: false }),
  icons: cmsIcons,
  pages: [
    ...editorPages,
  ],
});
````


**3.2 Server-side storage.** Reads the request school's published content on the server. Replace the tenant helper import with this template's own TENANT_HOST helper and call it the way it is meant to be called. Examples: `const tenantHost = await getTenantHost();` or `const { tenantHost } = await getTenantContext();`. If the template has no helper, create `CONFIG_DIR/lib/cms-tenant.ts` with a `getTenantHost()` that copies the exact logic its fetchers already use to pick the tenant host (environment override, `x-tenant-host`, `x-forwarded-host`, `host`), and import that. Do not invent new logic.

#### `CONFIG_DIR/lib/cms-server-storage.ts`

````ts
import { djangoAdapter } from './storio-editor';
import { getTenantHost } from '<TENANT_HELPER_IMPORT>'; // TENANT_HOST: this template's own helper (INPUTS)

// Same backend URL the Storio SDK uses on the server.
const BACKEND_URL =
  process.env.BACKEND_INTERNAL_URL ||
  process.env.NEXT_PUBLIC_API_URL ||
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  'http://127.0.0.1:8000';

/** Server-side reads of this school's published content (the tenant comes from the request). */
export async function serverCmsStorage() {
  const tenantHost = await getTenantHost();
  return djangoAdapter({
    baseUrl: `${BACKEND_URL.replace(/\/+$/, '')}/api/cms`,
    credentials: 'omit',
    media: false,
    headers: { 'x-tenant-host': tenantHost },
  });
}
````


**3.3 Client provider.**

#### `CONFIG_DIR/components/cms/CmsClientProviders.tsx`

````tsx
'use client';

import { CmsProvider } from '../../lib/storio-editor/site';
import { cms } from '../../cms.config';

export function CmsClientProviders({
  initialContent,
  children,
}: {
  initialContent?: Record<string, Record<string, unknown>>;
  children: React.ReactNode;
}) {
  return (
    <CmsProvider config={cms} initialContent={initialContent}>
      {children}
    </CmsProvider>
  );
}
````


**3.4 Server provider.** Loads the school's published content for every editor page on the server (and the styles of Theme settings texts), so visitors get the edited content in the first HTML. If NEXT_VERSION is below 15, `connection` does not exist: replace `import { connection } from 'next/server';` with `import { unstable_noStore as noStore } from 'next/cache';` and `await connection();` with `noStore();`.

#### `CONFIG_DIR/components/cms/CmsProviders.tsx`

````tsx
import { connection } from 'next/server';
import { getAllPageContent } from '../../lib/storio-editor/server';
import { STYLES_KEY } from '../../lib/storio-editor/core/styles';
import { cms } from '../../cms.config';
import { serverCmsStorage } from '../../lib/cms-server-storage';
import { THEME_PAGE } from './themePage';
import { CmsClientProviders } from './CmsClientProviders';

// Loads the school's published content on the server, so the first HTML already contains the
// edited text. If Storio cannot be reached, every page falls back to its defaults.
export async function CmsProviders({ children }: { children: React.ReactNode }) {
  await connection(); // content can change at any moment from the dashboard
  const storage = await serverCmsStorage();
  const [initialContent, themeStyles] = await Promise.all([
    cms.pages.length > 0 ? getAllPageContent(cms, { storage }) : Promise.resolve({}),
    // Styles of the texts with a Theme settings pencil (<ThemeField>), so they render on the server.
    storage.getRecord(THEME_PAGE, STYLES_KEY).catch(() => null),
  ]);
  const content: Record<string, Record<string, unknown>> = { ...initialContent };
  if (themeStyles?.content && typeof themeStyles.content === 'object') {
    content[THEME_PAGE] = { [STYLES_KEY]: themeStyles.content };
  }
  return <CmsClientProviders initialContent={content}>{children}</CmsClientProviders>;
}
````


**3.5 The Theme settings page key.** Replace `<TEMPLATE_ID>`.

#### `CONFIG_DIR/components/cms/themePage.ts`

````ts
/**
 * The Storio editor's "Theme settings" page: its key is the template id, and the manifest's
 * "customization" groups are its sections. Used by <ThemeField> and by CmsProviders (server).
 */
export const THEME_PAGE = '<TEMPLATE_ID>';
````


**3.6 The Theme settings pencil.** A pencil for a text the template reads from its customization. It opens that field under Theme settings in the editor, shows the typed value live in the preview, and supports the Style tab.

#### `CONFIG_DIR/components/cms/ThemeField.tsx`

````tsx
'use client';

import { useEffect, useRef, useState } from 'react';
import { CmsField } from '../../lib/storio-editor/site';
import { THEME_PAGE } from './themePage';

/**
 * A pencil for a text the template reads from its customization (Theme settings), such as
 * "about_section_title". It opens that same Theme settings field in the editor, so the text has one
 * source: the published value goes into the live customization the template already reads.
 *
 * Live preview: the template renders these texts from the server's customization, which the
 * editor's typing does not reach. So inside the editor preview this listens for the editor's draft
 * messages itself and shows the typed value while it differs from the rendered text (untouched
 * fields keep their own markup); after a save or reset it reloads the preview to show the stored
 * value. Visitors see the children unchanged.
 */
export default function ThemeField({
  field,
  label,
  section = 'content',
  children,
}: {
  field: string;
  label?: string;
  section?: string;
  children: React.ReactNode;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [draft, setDraft] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || window.parent === window || !ref.current) return;
    // The text as rendered from the customization (without a field style's <style>/<link>).
    const copy = ref.current.cloneNode(true) as HTMLElement;
    copy.querySelectorAll('style, link, script').forEach((node) => node.remove());
    const rendered = (copy.textContent ?? '').trim();
    let hasDraft = false;
    const onMessage = (event: MessageEvent) => {
      if (event.source !== window.parent || event.origin !== window.location.origin) return;
      const data = event.data as { type?: string; page?: string; sectionKey?: string; draftContent?: Record<string, unknown> };
      if (!data || typeof data !== 'object') return;
      if (data.type === 'CMS_DRAFT_PREVIEW' && data.page === THEME_PAGE && data.sectionKey === section) {
        const value = data.draftContent?.[field];
        const next = typeof value === 'string' && value.trim() !== rendered ? value : null;
        hasDraft = next !== null;
        setDraft(next);
      } else if (data.type === 'CMS_CONTENT_UPDATED' && hasDraft) {
        window.location.reload();
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [field, section]);

  // The measuring span sits outside CmsField: a field style (Style tab) must land on the field's own
  // box, never on a display: contents element, which cannot show spacing, background or alignment.
  return (
    <span ref={ref} style={{ display: 'contents' }}>
      <CmsField section={section} page={THEME_PAGE} path={field} label={label}>
        {draft !== null ? draft : children}
      </CmsField>
    </span>
  );
}
````


**3.7 Root layout.** In `APP_DIR/layout.*`, wrap everything inside `<body>` (the header and footer included) in `<CmsProviders>...</CmsProviders>` (import it from `CONFIG_DIR/components/cms/CmsProviders`). Keep every existing provider, element and attribute, in the same order, inside it. Change nothing else.

**3.8 Middleware.** Only if the template has a `middleware.ts` that redirects requests: do not redirect the editor preview. Wrap each redirect:

````ts
import { isCmsPreviewRequest } from '<KIT_DIR>/server';
if (!isCmsPreviewRequest(request, { studioPath: '/dashboard/settings/template-customization' })) {
  // ...existing redirect, unchanged...
}
````

**3.9 Sync and check script.** Copies `content/<page key>.json` into the manifest, writes the icon list, and checks every rule the Storio backend enforces. It must never call `process.exit` (Storio's publish security scan refuses it).

#### `scripts/storio-editor-sync.mjs` (at the PROJECT ROOT, next to package.json)

````js
#!/usr/bin/env node
// Storio Elements Editor: copies content/<page key>.json into public/storio.template.json
// (editorPages[].defaults), writes lib/cms-icons.generated.ts from "editorIcons", and checks the
// rules the Storio backend enforces.
//   node scripts/storio-editor-sync.mjs           copy defaults, write icons, then check
//   node scripts/storio-editor-sync.mjs --check   check only (used before every build)
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const manifestPath = path.join(root, 'public', 'storio.template.json');
const contentDirs = [path.join(root, 'content'), path.join(root, 'src', 'content')];
const checkOnly = process.argv.includes('--check');
const KEY = /^[A-Za-z0-9_-]{1,100}$/;
const COLLECTIONS = ['notice', 'blog', 'event']; // the Storio records editable on [slug]/[id] pages
const rel = (p) => path.relative(root, p).split(path.sep).join('/');

const raw = fs.readFileSync(manifestPath, 'utf8');
const manifest = JSON.parse(raw);
const id = String(manifest.id || '');
const listed = manifest.editorPages ?? [];
const pages = Array.isArray(listed) ? listed : [];
const errors = [];
const warnings = [];
let changed = false;

// Never end the script with an exit call: Storio's publish security scan refuses it. process.exitCode = 1 below still
// makes `npm run build` (prebuild) fail.
if (!Array.isArray(listed)) errors.push('"editorPages" must be a list.');
if (pages.length > 0 && manifest.editor !== 'storio-elements') {
  warnings.push('No "editor": "storio-elements" in the manifest yet: the dashboard keeps the classic customizer until you add it.');
}

const themeKeys = new Set(['navigation']);
for (const [group, fields] of Object.entries(manifest.customization || {})) {
  if (Array.isArray(fields) && fields.length > 0) themeKeys.add(group);
}

const seen = new Set();
pages.forEach((page, i) => {
  const where = `editorPages[${i}]`;
  if (!page || typeof page !== 'object') return errors.push(`${where} must be an object.`);
  if (typeof page.key !== 'string' || !KEY.test(page.key)) errors.push(`${where}.key: letters, digits, "_" or "-" only.`);
  else if (!page.key.startsWith(`${id}-`)) errors.push(`${where}.key "${page.key}" must start with "${id}-".`);
  else if (seen.has(page.key)) errors.push(`${where}.key "${page.key}" is used twice.`);
  else seen.add(page.key);
  if (typeof page.title !== 'string' || !page.title.trim()) errors.push(`${where}.title is required.`);
  const dynamic = typeof page.route === 'string' && /\[[^\]]+\]/.test(page.route);
  if (typeof page.route !== 'string' || !page.route.startsWith('/')) errors.push(`${where}.route must start with "/".`);
  else if (/[?#]/.test(page.route)) errors.push(`${where}.route must be a path without "?" or "#".`);
  else if (dynamic && !('collection' in page)) errors.push(`${where}.route "${page.route}" needs "collection" (${COLLECTIONS.join(', ')}).`);
  else if (!dynamic && 'collection' in page) errors.push(`${where}.collection needs a route with [slug] or [id].`);
  if ('collection' in page && !COLLECTIONS.includes(page.collection)) errors.push(`${where}.collection must be one of: ${COLLECTIONS.join(', ')}.`);
  if ('parent' in page) {
    const parent = pages.find((p) => p && p.key === page.parent);
    if (!('collection' in page)) errors.push(`${where}.parent is only for pages with "collection".`);
    else if (!parent || parent === page || 'parent' in parent || parent.global) errors.push(`${where}.parent must be the key of another, non-global list page.`);
  }
  if ('global' in page && typeof page.global !== 'boolean') errors.push(`${where}.global must be true or false.`);
  if (page.global === true && ('collection' in page || 'parent' in page)) errors.push(`${where}: the global page cannot have "collection" or "parent".`);
  if (!Array.isArray(page.sections) || (page.sections.length === 0 && !('collection' in page))) return errors.push(`${where}.sections must be a non-empty list.`);
  const sectionKeys = [];
  page.sections.forEach((s, j) => {
    if (!s || typeof s.key !== 'string' || !KEY.test(s.key) || s.key.startsWith('_')) errors.push(`${where}.sections[${j}].key is invalid.`);
    else if (sectionKeys.includes(s.key)) errors.push(`${where}.sections[${j}].key "${s.key}" is used twice.`);
    else sectionKeys.push(s.key);
    if (!s || typeof s.label !== 'string' || !s.label.trim()) errors.push(`${where}.sections[${j}].label is required.`);
  });

  const file = typeof page.key === 'string' ? contentDirs.map((d) => path.join(d, `${page.key}.json`)).find((f) => fs.existsSync(f)) : undefined;
  if (!file) {
    if (!page.defaults || typeof page.defaults !== 'object') errors.push(`${where}: no content/${page.key}.json and no "defaults".`);
    return;
  }
  const content = JSON.parse(fs.readFileSync(file, 'utf8'));
  for (const k of Object.keys(content)) if (!sectionKeys.includes(k)) errors.push(`${where}: "${k}" in ${rel(file)} is not in "sections".`);
  for (const k of sectionKeys) if (!(k in content)) errors.push(`${where}: section "${k}" has no content in ${rel(file)}.`);
  if (JSON.stringify(page.defaults) !== JSON.stringify(content)) {
    if (checkOnly) errors.push(`${where}: "defaults" differ from ${rel(file)}. Run: npm run editor:sync`);
    else {
      page.defaults = content;
      changed = true;
    }
  }
});

// The Storio dashboard makes Theme settings the editor's site-wide page only when no template page
// is global and no section is named like a Theme settings group; otherwise every <ThemeField>
// pencil (a text read from the customization) stops working.
pages.forEach((p, i) => {
  if (!p || typeof p !== 'object') return;
  if (p.global === true) errors.push(`editorPages[${i}]: "global": true stops the Theme settings pencils from working. Remove it (see STEP 6).`);
  (Array.isArray(p.sections) ? p.sections : []).forEach((s) => {
    if (s && themeKeys.has(s.key)) errors.push(`editorPages[${i}]: section "${s.key}" has the name of a Theme settings group ("navigation" or a "customization" group). Rename it.`);
  });
});

// Icons: "editorIcons" lists lucide-react icon names; the generated file imports exactly those.
const icons = manifest.editorIcons ?? [];
const ICON = /^[A-Z][A-Za-z0-9]{0,63}$/;
if (!Array.isArray(icons)) errors.push('"editorIcons" must be a list of lucide-react icon names.');
else {
  if (icons.length > 300) errors.push('"editorIcons" may list at most 300 icons.');
  icons.forEach((name, i) => {
    if (typeof name !== 'string' || !ICON.test(name)) errors.push(`editorIcons[${i}] must be a lucide-react icon name such as "GraduationCap".`);
    else if (icons.indexOf(name) !== i) errors.push(`editorIcons[${i}] "${name}" is listed twice.`);
  });
}
const iconNames = Array.isArray(icons) ? icons.filter((n) => typeof n === 'string' && ICON.test(n)) : [];
const libDir = fs.existsSync(path.join(root, 'src', 'app')) ? path.join(root, 'src', 'lib') : path.join(root, 'lib');
const iconsFile = path.join(libDir, 'cms-icons.generated.ts');
const iconsSource =
  '// Generated by scripts/storio-editor-sync.mjs from "editorIcons" in public/storio.template.json.\n' +
  '// Do not edit: add or remove icon names in the manifest, then run `npm run editor:sync`.\n' +
  (iconNames.length ? `import { ${iconNames.join(', ')} } from 'lucide-react';\n\n` : '\n') +
  `export const cmsIcons = ${iconNames.length ? `{ ${iconNames.join(', ')} }` : '{}'};\n`;
const currentIcons = fs.existsSync(iconsFile) ? fs.readFileSync(iconsFile, 'utf8').replace(/\r\n/g, '\n') : null;
if (currentIcons !== iconsSource) {
  if (checkOnly) errors.push(`${rel(iconsFile)} is missing or out of date. Run: npm run editor:sync`);
  else {
    fs.mkdirSync(libDir, { recursive: true });
    fs.writeFileSync(iconsFile, iconsSource);
    console.log(`storio-editor-sync: wrote ${rel(iconsFile)} (${iconNames.length} icon(s))`);
  }
}

if (changed && !checkOnly) {
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2).replace(/\n/g, eol) + eol);
  console.log(`storio-editor-sync: updated defaults in ${rel(manifestPath)}`);
}
if (warnings.length > 0) console.warn('storio-editor-sync warning:\n- ' + warnings.join('\n- '));
if (errors.length > 0) {
  console.error('storio-editor-sync found problems:\n- ' + errors.join('\n- '));
  process.exitCode = 1;
} else {
  console.log(`storio-editor-sync: ${pages.length} editor page(s) OK`);
}
````


**3.10 package.json scripts.** Add (keep every existing script):

- `"editor:sync": "node scripts/storio-editor-sync.mjs"`
- `"editor:check": "node scripts/storio-editor-sync.mjs --check"`
- `"prebuild": "node scripts/storio-editor-sync.mjs --check"` (if a `prebuild` exists, append ` && node scripts/storio-editor-sync.mjs --check` to it)
- If a `sync` script exists (it pushes the manifest to Storio), make it run `node scripts/storio-editor-sync.mjs && ` before its current command.

**3.11** Run `npm run editor:sync` once: it creates `CONFIG_DIR/lib/cms-icons.generated.ts` (empty for now). Then `npx tsc --noEmit` and `npm run build` must pass and the site must look exactly the same (no page is converted yet).

### STEP 4. How to convert a component (the method; read it fully before STEP 5)

You convert by hand. For each component that renders static content:

**4.1 Decide the sections.** One `<CmsSection>` per visual section of the page (hero, about, features, call to action...), usually one per section component. Give each a meaningful section key and title (NAMING RULES). A section's fields are the static texts, images and icons inside it.

**4.2 Make it a client component when needed.** Reading page content uses a hook, so the component must be a client component:

- it already has `'use client'` at the top: fine;
- it has no server-only code (not `async`, no `metadata`/`generateMetadata` export, no `headers()`/`cookies()`/database/`fs`/server-only imports): add `'use client';` as the first line. Its props must be serialisable (plain data, no functions passed from a Server Component); if not, use the next option;
- otherwise keep the server component for data fetching, move its JSX into a new client component next to it (for example `HeroView.tsx` with `'use client'`), pass the fetched data as props, and render it from the server component. The HTML must stay the same.

`<CmsSection>`, `<CmsField>` and `<ThemeField>` may be used inside Server Components too (they are client components themselves); only the `use<Page>Text` hook needs a client component.

**4.3 Move the static content into the defaults**, `CONFIG_DIR/content/<page key>.json`: one object per section key, one entry per field, the value being **exactly the text as written in the code** (decode JSX entities: `&amp;` → `&`, `&apos;` → `'`; keep every other character). Trim only whitespace at the start and end; keep that surrounding whitespace in the JSX around the `<CmsField>`.

**4.4 Render it from the content and wrap it.**

- Wrap the section's outermost element: `<CmsSection sectionKey="<key>" title="<Title>" page="<page key>">...</CmsSection>`. Always pass `page=`.
- Replace each literal text with the field and wrap it **inside** its element: `<h2 className="..."><CmsField path="title" label="Title">{text.hero.title}</CmsField></h2>`. The element, its classes and attributes stay as they are. Put `<CmsField>` inside `<li>`, `<td>`, `<option>` parents, never around them.
- A text broken by inline markup becomes one field per text run, the markup stays in the code: `Welcome to <span className="text-primary">Our School</span>` → `<CmsField path="titleStart">{t.titleStart}</CmsField> <span className="text-primary"><CmsField path="titleHighlight">{t.titleHighlight}</CmsField></span>`. Never put HTML into a content value.
- A `<br />` inside a text: split into two fields around it (keep the `<br />`).
- Attributes (`alt`, `placeholder`, `aria-label`, `title`): move the literal value into a field (`imageAlt`, `searchPlaceholder`...) and use it in the attribute. No `<CmsField>` for them (the section form edits them).
- Text inside `<title>`, `<option>`, `<textarea>` or used as a string argument (for example a `toast("Saved")`): move it into a field if it is shown to visitors, without `<CmsField>`.
- A static array or object in the code (`const features = [{ title: 'Small classes', icon: Star }, ...]`): move its displayable values into the section as an array (`"features": [{ "title": "Small classes", "icon": "Star" }]`), keep anything else (hrefs, ids, colours, logic) in the code (merge them by index), and map over the content: ``text.hero.features.map((f, i) => ... <CmsField path={`features.${i}.title`} label="Feature title">{f.title}</CmsField> ...)``. Keep the same `key` prop expression as before when it does not depend on moved values; otherwise use the index.
- Text that is the fallback of customization or API data (`{customization?.x || 'Welcome'}`, `{profile.name ?? 'Our School'}`): it is not static content. Customization → `<ThemeField>` (STEP 5.7). API data → leave it as it is, no pencil.
- Conditional texts (`{isOpen ? 'Open' : 'Closed'}`): move both literals into fields (`openText`, `closedText`), keep the condition: `{isOpen ? <CmsField path="openText">{t.openText}</CmsField> : <CmsField path="closedText">{t.closedText}</CmsField>}`.
- Leave alone: numbers, dates and values computed in code, URLs and hrefs, class names, ids, single characters used as decoration (`→`, `•`, `|`) when they are separate from text, and text inside SVG.

**4.5 Example.** Before:

````tsx
import { Star } from 'lucide-react';

const features = [
  { title: 'Small classes', href: '/classes' },
  { title: 'Caring teachers', href: '/teachers' },
];

export default function Hero() {
  return (
    <section className="hero py-20">
      <h1 className="text-4xl font-bold">Welcome to <span className="text-primary">Our School</span></h1>
      <p className="mt-4">Learning that lasts a lifetime.</p>
      <img src="/images/hero.jpg" alt="Students in class" className="w-full rounded-xl" />
      <a href="/admission" className="btn">Apply Now</a>
      <ul>
        {features.map((f) => (
          <li key={f.href}><a href={f.href}><Star className="h-5 w-5" /> {f.title}</a></li>
        ))}
      </ul>
    </section>
  );
}
````

After:

````tsx
'use client';

import { CmsField, CmsIcon, CmsSection } from '<relative or ALIAS path>/lib/storio-editor/site';
import { useHomeText } from '<relative or ALIAS path>/components/cms/useHomeText';

const featureLinks = ['/classes', '/teachers'];

export default function Hero() {
  const text = useHomeText();
  return (
    <CmsSection sectionKey="hero" title="Hero" page="<TEMPLATE_ID>-home">
      <section className="hero py-20">
        <h1 className="text-4xl font-bold"><CmsField path="titleStart" label="Title">{text.hero.titleStart}</CmsField> <span className="text-primary"><CmsField path="titleHighlight" label="Title highlight">{text.hero.titleHighlight}</CmsField></span></h1>
        <p className="mt-4"><CmsField path="subtitle" label="Subtitle">{text.hero.subtitle}</CmsField></p>
        <CmsField path="image" label="Image">
          <img src={text.hero.image} alt={text.hero.imageAlt} className="w-full rounded-xl" />
        </CmsField>
        <a href="/admission" className="btn"><CmsField path="buttonText" label="Button">{text.hero.buttonText}</CmsField></a>
        <ul>
          {text.hero.features.map((f, i) => (
            <li key={featureLinks[i] ?? i}><a href={featureLinks[i]}><CmsField path={`features.${i}.icon`} label="Icon"><CmsIcon name={f.icon} className="h-5 w-5" /></CmsField> <CmsField path={`features.${i}.title`} label="Feature">{f.title}</CmsField></a></li>
          ))}
        </ul>
      </section>
    </CmsSection>
  );
}
````

`CONFIG_DIR/content/<TEMPLATE_ID>-home.json`:

````json
{
  "hero": {
    "titleStart": "Welcome to",
    "titleHighlight": "Our School",
    "subtitle": "Learning that lasts a lifetime.",
    "image": "/images/hero.jpg",
    "imageAlt": "Students in class",
    "buttonText": "Apply Now",
    "features": [
      { "icon": "Star", "title": "Small classes" },
      { "icon": "Star", "title": "Caring teachers" }
    ]
  }
}
````

and `"Star"` is added to the manifest's `editorIcons` (STEP 5.9).

### STEP 5. Convert the pages, one at a time, homepage first

For each page of PAGES:

**5.1 Record the visible text BEFORE.** Start the dev server and save the page's visible text:

````bash
curl -s http://localhost:<port><route> | node -e "let h='';process.stdin.on('data',d=>h+=d).on('end',()=>console.log(h.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/g,'').replace(/<[^>]+>/g,' ').replace(/&nbsp;/g,' ').replace(/\s+/g,' ').trim()))" > .storio-before.txt
````

**5.2 List the content.** Go through the page file and every component it renders (follow the imports, but not into shared layout components: those are STEP 6). Write down, per component: the static texts, attributes, images and lucide icons it shows (STEP 4.4 rules), the customization texts it shows (for `<ThemeField>`) and the API data (no pencil). Decide the sections and field names now.

**5.3 Create the defaults file** `CONFIG_DIR/content/<page key>.json` with every section and field (STEP 4.3). If the page has a "seo" section (STEP 5.10), add it too.

**5.4 Add the page to the manifest.** In `public/storio.template.json`, add to `"editorPages"` (create the list if it does not exist):

````json
{ "key": "<page key>", "title": "<Page name>", "route": "<route>", "sections": [ { "key": "hero", "label": "Hero" }, { "key": "about", "label": "About" } ] }
````

The route is the page's real URL starting with `/`. The sections are exactly the keys of the defaults file, in the page's order. Then run `npm run editor:sync`: it copies the defaults into the manifest and checks every rule. Fix every problem it reports.

**5.5 Create the page's text helper** `CONFIG_DIR/components/cms/use<Page>Text.ts` (for example `useHomeText` for the homepage). Exactly this, with the names filled in. It fills each section from the defaults before the school's saved values, so a field added later never shows up empty for a school that already saved that section:

````ts
'use client';

import { usePageContent } from '../../lib/storio-editor/site';
import pageDefaults from '../../content/<page key>.json';

export type <Page>Text = typeof pageDefaults;

/**
 * The editable texts of the page "<page key>" (Storio editor). Each section is filled from the
 * defaults first, then overlaid with the school's saved values.
 */
export function use<Page>Text(): <Page>Text {
  const content = usePageContent<<Page>Text>('<page key>') as Record<string, unknown>;
  const merged: Record<string, unknown> = {};
  for (const [section, defaults] of Object.entries(pageDefaults)) {
    const saved = content?.[section];
    merged[section] =
      defaults && typeof defaults === 'object' && !Array.isArray(defaults) && saved && typeof saved === 'object' && !Array.isArray(saved)
        ? { ...defaults, ...saved }
        : (saved ?? defaults);
  }
  return merged as <Page>Text;
}
````

**5.6 Convert each component** with the method of STEP 4: client component if needed, `const text = use<Page>Text();`, `<CmsSection ... page="<page key>">`, every static text in its own `<CmsField>`, attributes from the content.

**5.7 Customization texts → `<ThemeField>`.** For each text the component renders from the customization (a `LiveText field="..."`, `customization?.field_id || 'fallback'`, `config.field_id`...), keep the rendering exactly as it is and wrap it:

````tsx
<h2 className="..."><ThemeField field="about_section_title" label="Title"><LiveText field="about_section_title" initial={customization?.about_section_title} fallback="About Us" /></ThemeField></h2>
````

`field` is the customization field id. Add `section="<group>"` when the field is not in the manifest's `content` group. Do not use `<ThemeField>` for a customization field that holds an image path (the editor would offer the icon picker for ids ending in "icon"); leave those without a pencil, or see 5.8.

**5.8 Static images.** For every image with a fixed path (`<img src="/images/a.jpg">`, `next/image`, CSS `backgroundImage: 'url(/images/a.jpg)'`):

- put the path in the section under an image field name (`image`, `heroImage`...) and its `alt` under `<name>Alt`;
- render it from the content and wrap the element: `<CmsField path="image" label="Image"><img src={text.hero.image} alt={text.hero.imageAlt} className="<same>" /></CmsField>`; keep the element, classes, sizes and every other prop;
- `next/image`: admins upload images to Storio, which returns absolute URLs on the school's domain (`https://<school>/media/cms-uploads/...`). Add `unoptimized={src.startsWith('http') || src.startsWith('/media/')}` (with `src` being the content value) so those display without listing every school domain; the default local image stays optimized as before;
- CSS background: build the same `url(...)` from the content value and wrap the element that has the background;
- an image that is only the fallback of API or customization data (`src={profile.image_url || '/images/about.jpg'}`): render `apiValue || text.section.image` and wrap it; say in the report that the API value wins when set. If a customization value is stored even when the school never changed it (it then equals the manifest default), use it only when it differs from that default, otherwise the editor's image would never show.

**5.9 Static lucide icons** (`<GraduationCap className="h-6 w-6" />` imported from `lucide-react`):

- put the icon name in the section under an icon field name (`icon`, `featureIcon`; inside each item of an array);
- add every such name to the manifest's top-level `"editorIcons"` list (create it), plus any other lucide icons the template should offer; run `npm run editor:sync` (it regenerates `CONFIG_DIR/lib/cms-icons.generated.ts`, which `cms.config.ts` passes to the editor);
- replace the icon: `<CmsField path="icon" label="Icon"><CmsIcon name={text.section.icon} className="<same classes>" /></CmsField>`, keeping every prop it had (`className`, `size`, `strokeWidth`, `style`...). `CmsIcon` comes from `<KIT_DIR>/site`;
- icons that are image files: treat them as images (5.8). Inline `<svg>` drawings and other icon libraries: leave them as they are.

**5.10 Page SEO** (title, description, keywords, share image). Only when the page file is a Server Component (no `'use client'`); otherwise skip and report it.

- Add the section `{ "key": "seo", "label": "SEO" }` to the page's manifest entry and to the defaults: `"seo": { "title": "", "description": "", "keywords": [], "ogImage": "" }`. Empty means "keep the page's current metadata". If the current metadata has static keywords, copy them into `keywords`.
- Replace the page's `export const metadata = {...}` / `export async function generateMetadata(...)` with (keep the same function parameters if it had any):

````tsx
import type { Metadata } from 'next';
import { getPageMetadata } from '<KIT_DIR as import path>/server';
import { cms } from '<CONFIG_DIR as import path>/cms.config';
import { serverCmsStorage } from '<CONFIG_DIR as import path>/lib/cms-server-storage';

export async function generateMetadata(): Promise<Metadata> {
  const fallback: Metadata = <the old metadata object, or the old generateMetadata result>;
  try {
    return await getPageMetadata(cms, '<page key>', { storage: await serverCmsStorage(), fallback, site: false });
  } catch {
    return fallback;
  }
}
````

  A page without metadata of its own uses `const fallback: Metadata = {}`.
- Check: `curl -s http://localhost:<port><route> | grep -o "<title>[^<]*</title>"` shows the same title as before. (The page now also gets og:/twitter: tags from the same title and description; that is expected.)

**5.11** Run `npm run editor:sync` (no problems) and `npx tsc --noEmit`.

**5.12 Record the visible text AFTER** the same way into `.storio-after.txt` and compare: `git diff --no-index .storio-before.txt .storio-after.txt`. **There must be no difference.** If there is one, find the field whose default differs from the original text (a lost space, a changed character, a missing text) and fix it. Then delete both `.txt` files. Look at the page in a browser too: layout, images and icons must look exactly as before.

**5.13** `npm run build` must pass. Then continue with the next page.

### STEP 6. Header and footer (once)

- Never add a page with `"global": true`.
- Header/footer texts that come from the customization: wrap them in `<ThemeField>` as in 5.7. These pencils then work on every page.
- Hard-coded header/footer texts: leave them unchanged and list them in the report (they cannot get a pencil without a site-wide page).
- Data from the Storio API (school name, logo, phone, social links, navigation menu): no pencil.
- Verify the site looks the same, type check and build.

### STEP 7. Notice, blog and event detail pages (RECORD_PAGES)

Admins can then open a notice, blog post or event in the editor and change these fields in the preview. The save changes the same record the dashboard's Notices/Blogs/Events pages edit and goes live at once (records have no drafts).

| collection | record id in the URL | editable fields |
|---|---|---|
| `notice` | the notice's id | `title` |
| `blog` | the post's slug | `title`, `excerpt` |
| `event` | the event's slug | `title`, `excerpt`, `location` |

For each RECORD_PAGE:

1. Add it to `"editorPages"`: `{ "key": "<TEMPLATE_ID>-<name>-detail", "title": "Notice", "route": "<its route with the bracket, e.g. /notice/[id]>", "collection": "notice", "parent": "<page key of its list page>", "sections": [] }`. Add `"parent"` only when the list page (for example `/notice`) is in `"editorPages"`; otherwise leave it out. Fixed texts of the detail page stay as they are; `"sections"` stays empty.
2. Wrap each editable field where the page shows it, with the record's own value and id. Keep the element and its classes; only the wrapper is new (works in Server Components too):

````tsx
import { CmsField } from '<KIT_DIR as import path>/site';

<h1 className="..."><CmsField collection="notice" item={String(notice.id)} path="title">{notice.title}</CmsField></h1>
<p className="..."><CmsField collection="blog" item={post.slug} path="excerpt">{post.excerpt}</CmsField></p>
<span><CmsField collection="event" item={event.slug} path="location">{event.location}</CmsField></span>
````

   Only plain text fields from the table; never bodies (rich text or `dangerouslySetInnerHTML`), dates, images, categories or slugs.
3. Optional: wrap the same fields on the list pages and on the homepage cards the same way.
4. Check with one real record: the visible-text comparison shows no difference; `npm run editor:sync`, `npx tsc --noEmit` and `npm run build` pass.

### STEP 8. Turn the editor on

In `public/storio.template.json` add the top-level field `"editor": "storio-elements"` (next to `"id"`). Run `npm run editor:sync`, `npx tsc --noEmit` and `npm run build`.

### STEP 9. Test with Storio (local)

1. The dashboard reads the manifest of the template's **approved published version**: increase `"version"` in `public/storio.template.json` (for example 1.2.6 → 1.2.7), run `storio publish --local`, then approve the submission in the local SaaS admin. Every later manifest change (a page, section or field) needs the same: higher version, publish, approve. If publishing reports "Package validation failed", fix what it names.
2. Run the template as a **production build** on the port the local Storio gateway uses for it (`TEMPLATE_*_INTERNAL_URL` in storio-cms `frontend-next/.env.local`), not `npm run dev` (behind the gateway, a template dev server does not hydrate, so the preview shows no pencils; production is not affected). Read the local backend and the test school without editing `.env.local`. Stop the template's dev server first, then in PowerShell:

````powershell
$env:NEXT_PUBLIC_API_URL="http://localhost:8000"; $env:BACKEND_INTERNAL_URL="http://localhost:8000"; $env:NEXT_PUBLIC_STORIO_TENANT_HOST="<school>.localhost"
npm run build
npm start -- -p <port>
````

   (Git Bash: put the three `VAR=value` pairs in front of each command.) Use the school's host, never an empty value.
3. The test school must use this template for its live design. Open `http://<school>.localhost:3000/dashboard/settings/template-customization?base=<TEMPLATE_ID>` (signed in).
4. Expected:
   - the Storio editor (not the classic customizer), with this template's pages first and "Theme settings" last;
   - hovering a converted text shows a pencil; typing changes the preview live; Save draft keeps the live site unchanged (check in a private window); Publish changes it after a reload; Reset brings back the default;
   - Style tab: a text offers typography, spacing, size and background; an image offers size, aspect ratio, fit, corners and border; an icon offers colour, size, background and spacing. Changes show in the preview and, after Save & Publish, on the live site;
   - an image pencil lets you upload a new image; an icon pencil offers exactly the `editorIcons`;
   - a Theme settings pencil opens that field under Theme settings and follows the typing; after Publish the preview reloads with the new text;
   - SEO: set a title in a page's "SEO" section and publish: the live page's `<title>` changes. (If the school has an SEO title in the dashboard's General Settings, the gateway shows that one on every page instead: expected, not a template bug.)
   - Records: click a notice title on its detail page, change it and save: the live notice and the dashboard's Notices page show the new title within a minute. Change it back.
5. If the classic customizer opens instead: check that the new version was published AND approved, that its manifest has `"editor": "storio-elements"`, that the school's live design uses this template, and that `npm run editor:check` passes.

### STEP 10. Report to me

- Files created and changed.
- A table of every page of PAGES and RECORD_PAGES: route, page key, converted or skipped (and why), number of editable texts, images, icons, record fields, Theme settings pencils, and whether it has SEO.
- Everything you left without a pencil and why (including the hard-coded header/footer texts).
- The results of `npm run editor:check`, `npx tsc --noEmit`, `npm run build`, the visible-text comparisons, and the STEP 9 test (or why it could not be run).
- Do not commit.

---

## Appendix A. The editor kit (25 files)

Create each file at the path in its heading (`<KIT_DIR>` = `CONFIG_DIR/lib/storio-editor`) with exactly the content of the block below it.

#### File 1 of 25: `<KIT_DIR>/index.ts`

````ts
/**
 * Storio editor support for this template: makes the template's texts, images, icons and page SEO
 * editable from the Storio dashboard (Template Customization), without installing a library.
 *
 * The code comes from the Storio Elements Editor (v1.4.0) and keeps its structure exactly:
 * pages and sections in cms.config.ts (defineCms), <CmsProvider>, <CmsSection>, <CmsField>,
 * usePageContent, and the /api/cms/ API with the editor's preview messages (core/messages.ts).
 * Keep those identical, or the Storio dashboard can no longer edit this template.
 *
 *   '@/lib/storio-editor'         config and storage: defineCms, djangoAdapter, types
 *   '@/lib/storio-editor/site'    client components: CmsProvider, CmsSection, CmsField, usePageContent...
 *   '@/lib/storio-editor/server'  server helpers: getAllPageContent, getPageMetadata...
 */
export * from './core/types';
export { defineCms, findPage, findGlobalPage, resolveSectionPage, isValidKey } from './core/defineCms';
export { mergePageContent } from './core/merge';
export { restAdapter, CmsRequestError } from './adapters/rest';
export type { RestAdapterOptions } from './adapters/rest';
export { djangoAdapter } from './adapters/django';
export type { DjangoAdapterOptions } from './adapters/django';
````

#### File 2 of 25: `<KIT_DIR>/site.ts`

````ts
// Client components and hooks for editable content (see ./index.ts).
export { CmsProvider, usePageContent, useSiteContent, useCmsConfig } from './site/CmsProvider';
export type { CmsProviderProps } from './site/CmsProvider';
export { CmsThemeStyle } from './site/CmsThemeStyle';
export type { CmsThemeStyleProps } from './site/CmsThemeStyle';
export { CmsSection } from './site/CmsSection';
export type { CmsSectionProps } from './site/CmsSection';
export { CmsField } from './site/CmsField';
export type { CmsFieldProps } from './site/CmsField';
export { CmsIcon } from './site/CmsIcon';
export type { CmsIconProps } from './site/CmsIcon';
export { useCollectionItem } from './site/itemDrafts';
export { isCmsPreview, useCmsEditMode } from './site/preview';
````

#### File 3 of 25: `<KIT_DIR>/server.ts`

````ts
// Server helpers: read published content and page SEO on the server (see ./index.ts).
export {
  getPageContent,
  getAllPageContent,
  getPageMetadata,
  buildPageMetadata,
  getSiteMetadata,
  buildSiteMetadata,
} from './server/getPageContent';
export type { PageSeoConfig, SiteSeoConfig } from './server/getPageContent';
export { isCmsPreviewRequest } from './server/isCmsPreviewRequest';
````

#### File 4 of 25: `<KIT_DIR>/core/types.ts`

````ts
import type { ComponentType } from 'react';

/** Any icon component that accepts a className (lucide-react icons fit). */
export type IconComponent = ComponentType<{ className?: string }>;

/** One editable block of a page, e.g. "hero" or "faq". */
export interface SectionDef {
  /** Key of this section inside the page's content object. */
  key: string;
  /** Human-readable label shown in the studio. */
  label: string;
  icon?: IconComponent;
  /**
   * Optional normaliser applied to the section data before it is loaded into the
   * form (for example to fill in fields older saved content does not have).
   */
  transform?: (data: unknown) => unknown;
}

/** A public page the CMS can edit. */
export interface PageDef {
  /** Stable key used for storage, e.g. "home". Letters, digits, "_" and "-" only. */
  key: string;
  /** Title shown in the studio. */
  title: string;
  /**
   * Public route rendered in the preview iframe, e.g. "/" or "/pricing". A page that shows one
   * record of a collection uses brackets, e.g. "/blog/[slug]", together with `collection`.
   */
  route: string;
  /**
   * For a page that shows one record of a collection (a [slug] or [id] route): the collection key
   * served by your CMS API (`collections` of createCmsRouteHandler, or COLLECTIONS in Django).
   * The studio then lists the records, and fields wrapped in
   * <CmsField collection item path> edit the record itself.
   */
  collection?: string;
  /**
   * Key of the page this one belongs to, e.g. "blog" for "blog-post". The studio lists this
   * page's records in a second menu next to the parent page instead of in the page menu.
   */
  parent?: string;
  /**
   * Site-wide content: header, footer, contact details, SEO defaults, theme. The sections of a
   * global page can be edited from every page in the studio and read on every page of the site
   * (`useSiteContent`). Its `route` is only the page shown while "Site settings" is open.
   * At most one page may be global.
   */
  global?: boolean;
  /**
   * Global page only. False keeps its sections out of every other page's section list, so they
   * are listed only under "Site settings". A click on the header or footer in any preview still
   * opens them. Default: true.
   */
  listOnEveryPage?: boolean;
  icon?: IconComponent;
  /** Editable sections, in the order they appear in the studio. */
  sections: SectionDef[];
  /**
   * Default content for the page, keyed by section key. Saved overrides replace a
   * section as a whole; anything never edited keeps these values.
   */
  defaults: Record<string, unknown>;
}

/** A saved override for one section. Storage only ever holds overrides. */
export interface SectionRecord {
  page: string;
  sectionKey: string;
  content: unknown;
  isPublished: boolean;
  updatedAt: string | null;
  updatedBy?: string | null;
}

export interface SaveRecordInput {
  page: string;
  sectionKey: string;
  content: unknown;
  isPublished: boolean;
  updatedBy?: string | null;
}

export interface ListOptions {
  /** Include unpublished (draft) records. Servers honour this only for authorised users. */
  includeDrafts?: boolean;
}

export interface MediaItem {
  url: string;
  name: string;
  size?: number;
}

/**
 * Storage contract. Implement this to keep content anywhere (REST API, database,
 * files, memory). The studio and the public-site hooks talk only to this interface.
 */
export interface CmsStorageAdapter {
  listRecords(page?: string, options?: ListOptions): Promise<SectionRecord[]>;
  getRecord(page: string, sectionKey: string, options?: ListOptions): Promise<SectionRecord | null>;
  saveRecord(input: SaveRecordInput): Promise<SectionRecord>;
  /** Remove an override, so the section falls back to its default ("Reset"). */
  deleteRecord(page: string, sectionKey: string): Promise<void>;
  /** Optional: enables the upload tab of the image picker. */
  uploadMedia?(files: File[]): Promise<MediaItem[]>;
  /** Optional: enables the media-library tab of the image picker. */
  listMedia?(): Promise<MediaItem[]>;
  /** Optional: the records of a collection, for pages with a [slug] or [id] route. */
  listItems?(collection: string): Promise<CollectionItemSummary[]>;
  /** Optional: the editable values of one record, or null when it does not exist. */
  getItem?(collection: string, id: string): Promise<Record<string, unknown> | null>;
  /** Optional: save changed values of one record. Returns the record's values after saving. */
  saveItem?(collection: string, id: string, values: Record<string, unknown>): Promise<Record<string, unknown>>;
}

/** One record of a collection, as listed in the studio's record menu. */
export interface CollectionItemSummary {
  /** Identifier used to load and save the record (a slug or a database id). */
  id: string;
  /** Name shown in the record menu, e.g. the post title. */
  label: string;
  /**
   * Values for the brackets of the page route, e.g. { slug: "school" } for "/blog/[slug]".
   * A bracket without a value here uses the id.
   */
  params?: Record<string, string>;
}

/** Cap on how many items an array field may hold, to protect a layout. */
export interface CollectionLimit {
  max: number;
  label: string;
}

/** A ready-made image offered in the image picker's gallery. */
export interface ImagePreset {
  url: string;
  title: string;
  category: string;
  tag?: string;
}

export interface ImagePresetCategory {
  id: string;
  label: string;
}

/** Value edited by a code widget: an HTML/CSS/JS triple. */
export interface CodeValue {
  html: string;
  css: string;
  js: string;
}

export interface CodeWidgetProps {
  value: CodeValue;
  onChange: (value: CodeValue) => void;
}

export interface CmsWidgets {
  /**
   * Editor used for objects shaped like `{ html, css, js }`. Without it those
   * fields are edited as plain text areas.
   */
  code?: ComponentType<CodeWidgetProps>;
}

/** The look of one field on one device, as CSS values ("#7c3aed", "2rem", "var(--color-brand)"). */
export interface StyleProps {
  color?: string;
  fontSize?: string;
  fontWeight?: string;
  lineHeight?: string;
  letterSpacing?: string;
  textAlign?: string;
  fontFamily?: string;
  marginTop?: string;
  marginRight?: string;
  marginBottom?: string;
  marginLeft?: string;
  paddingTop?: string;
  paddingRight?: string;
  paddingBottom?: string;
  paddingLeft?: string;
  width?: string;
  maxWidth?: string;
  height?: string;
  backgroundColor?: string;
  borderRadius?: string;
  borderWidth?: string;
  borderColor?: string;
  objectFit?: string;
  /** Which part of an image stays visible when it is cropped, e.g. "center" or "top". */
  objectPosition?: string;
  /** Width-to-height ratio, e.g. "16 / 9". */
  aspectRatio?: string;
  opacity?: string;
}

/** One field's style. Desktop is the base; tablet and phone override it on narrower screens. */
export interface FieldStyle {
  /**
   * "image" when the field shows an image. Fit and focus then apply to the <img> itself, and
   * size, corners and border to its box, which clips the image.
   * "icon" when it shows an icon (an <svg> and no text): the font size sets the icon's size.
   */
  kind?: 'image' | 'icon';
  desktop?: StyleProps;
  tablet?: StyleProps;
  phone?: StyleProps;
}

/** A page's field styles (the "_styles" record): section key → field path → style. */
export type StyleSheetData = Record<string, Record<string, FieldStyle>>;

/** Presets and settings of the Style tab. Values can be CSS variables, e.g. "var(--color-brand-600)". */
export interface CmsStyleOptions {
  /** False hides the Style tab. Default: true. */
  enabled?: boolean;
  /** Colour presets by name, e.g. { Brand: 'var(--color-brand-600)' }. */
  colors?: Record<string, string>;
  /** Font size presets, e.g. { S: '1rem', M: '1.5rem', L: '2.5rem' }. */
  fontSizes?: Record<string, string>;
  /** Spacing presets for margin and padding, e.g. { None: '0', Small: '0.5rem' }. */
  spacing?: Record<string, string>;
  /** Corner radius presets, e.g. { None: '0', Round: '9999px' }. */
  radii?: Record<string, string>;
  /** Widths (px) below which the tablet and phone values apply. Default: 1024 and 768. */
  breakpoints?: { tablet?: number; phone?: number };
}

export interface CmsConfig {
  /** Pages the studio lists and the site can read. */
  pages: PageDef[];
  /** Where content is read from and saved to. */
  adapter: CmsStorageAdapter;
  /** Heading shown at the top of the studio. */
  title?: string;
  /**
   * Base URL of the public site when the studio runs on a different origin
   * (for example admin.example.com editing example.com). Defaults to the studio's origin.
   */
  publicSiteUrl?: string;
  /**
   * The URL the studio uses to show an image value as a thumbnail (default: the value itself).
   * For a site whose files are only reachable through a preview URL, such as a template served
   * through a gateway.
   */
  mediaUrl?: (src: string) => string;
  /** Extra origins allowed to exchange preview messages with the studio. */
  allowedOrigins?: string[];
  /**
   * The icons your site can draw, by the name stored in the content (for example the
   * registry your own <Icon name> component uses). When set, the icon picker offers exactly
   * these, so every icon an editor picks also renders on the site. `<CmsIcon>` draws from it.
   * Without it the picker offers a built-in list of popular lucide-react icons.
   */
  icons?: Record<string, IconComponent>;
  /**
   * Font names your site already loads (for example with next/font). A field whose name ends in
   * "font" (e.g. "headingFont") then offers exactly these in a list.
   */
  fonts?: string[];
  /**
   * The Style tab of a single field: presets offered next to the custom inputs, and breakpoints.
   * Styles are saved per page as the record "_styles", through the same storage adapter.
   */
  styles?: CmsStyleOptions;
  /**
   * Item limits for array fields. Keys are tried in this order:
   * "page.section.path", "page.path", "section.path", "page.section".
   */
  collectionLimits?: Record<string, CollectionLimit>;
  imagePresets?: ImagePreset[];
  imagePresetCategories?: ImagePresetCategory[];
  widgets?: CmsWidgets;
}

/** Metadata about a section that has a saved record (see listManagedSections). */
export interface SectionMetadata {
  page: string;
  sectionKey: string;
  hasCustomOverride: boolean;
  isPublished: boolean;
  updatedAt: string | null;
  updatedBy: string | null;
}

/** One section's current content plus its override status. */
export interface SectionDetail<T = unknown> extends SectionMetadata {
  content: T;
}
````

#### File 5 of 25: `<KIT_DIR>/core/defineCms.ts`

````ts
import type { CmsConfig, PageDef } from './types';

const KEY_PATTERN = /^[A-Za-z0-9_-]{1,100}$/;

/** True for keys safe to use as page or section identifiers in storage and URLs. */
export function isValidKey(key: string): boolean {
  return KEY_PATTERN.test(key);
}

/**
 * Validate and return a CMS configuration. Throws on duplicate or malformed keys
 * so mistakes surface at startup instead of as silent save failures.
 */
export function defineCms(config: CmsConfig): CmsConfig {
  const seen = new Set<string>();
  for (const page of config.pages) {
    if (!isValidKey(page.key)) {
      throw new Error(`[storio-editor] Invalid page key "${page.key}". Use letters, digits, "_" or "-".`);
    }
    if (seen.has(page.key)) {
      throw new Error(`[storio-editor] Duplicate page key "${page.key}".`);
    }
    seen.add(page.key);
    if (!page.route.startsWith('/')) {
      throw new Error(`[storio-editor] Page "${page.key}" route must start with "/".`);
    }
    if (page.listOnEveryPage !== undefined && !page.global) {
      throw new Error(`[storio-editor] Page "${page.key}" has listOnEveryPage, which only applies to the page with global: true.`);
    }
    if (page.collection !== undefined && !isValidKey(page.collection)) {
      throw new Error(`[storio-editor] Invalid collection "${page.collection}" on page "${page.key}".`);
    }
    if (/\[[^\]]+\]/.test(page.route) && !page.collection) {
      throw new Error(
        `[storio-editor] Page "${page.key}" has the route "${page.route}", which shows one record at a time. ` +
          'Add collection: "<key>" so the studio can list the records.'
      );
    }
    const sectionKeys = new Set<string>();
    for (const section of page.sections) {
      if (section.key === '_styles') {
        throw new Error(`[storio-editor] Section key "_styles" on page "${page.key}" is reserved for field styles. Rename the section.`);
      }
      if (!isValidKey(section.key)) {
        throw new Error(`[storio-editor] Invalid section key "${section.key}" on page "${page.key}".`);
      }
      if (sectionKeys.has(section.key)) {
        throw new Error(`[storio-editor] Duplicate section key "${section.key}" on page "${page.key}".`);
      }
      sectionKeys.add(section.key);
    }
  }
  const globalPages = config.pages.filter((p) => p.global);
  if (globalPages.length > 1) {
    throw new Error(
      `[storio-editor] Only one page may have global: true (found ${globalPages.map((p) => `"${p.key}"`).join(', ')}).`
    );
  }
  const globalPage = globalPages[0];
  if (globalPage) {
    if (globalPage.collection || globalPage.parent) {
      throw new Error(`[storio-editor] The global page "${globalPage.key}" cannot have a collection or a parent.`);
    }
    const globalKeys = new Set(globalPage.sections.map((s) => s.key));
    for (const page of config.pages) {
      if (page === globalPage) continue;
      const clash = page.sections.find((s) => globalKeys.has(s.key));
      if (clash) {
        throw new Error(
          `[storio-editor] Section "${clash.key}" is on page "${page.key}" and on the global page "${globalPage.key}". ` +
            'Rename one, so the studio knows which one a click means.'
        );
      }
    }
  }
  for (const page of config.pages) {
    if (!page.parent) continue;
    const parent = config.pages.find((p) => p.key === page.parent);
    if (!parent) throw new Error(`[storio-editor] Page "${page.key}" has the parent "${page.parent}", which is not a page.`);
    if (parent.parent) {
      throw new Error(`[storio-editor] Page "${page.key}": its parent "${parent.key}" has a parent itself. Use one level only.`);
    }
    if (!page.collection) {
      throw new Error(`[storio-editor] Page "${page.key}" has a parent, so it must show records: add collection: "<key>".`);
    }
  }
  return config;
}

/** The page with `global: true` (site-wide content), if any. */
export function findGlobalPage(config: Pick<CmsConfig, 'pages'>): PageDef | undefined {
  return config.pages.find((p) => p.global);
}

/**
 * Which page a section belongs to, as seen from the page open in the studio: the page named by
 * the click, else the open page, else the global page.
 */
export function resolveSectionPage(
  config: Pick<CmsConfig, 'pages'>,
  currentPage: string,
  sectionKey: string,
  requestedPage?: string
): string | undefined {
  const has = (key: string | undefined) => !!key && !!findPage(config, key)?.sections.some((s) => s.key === sectionKey);
  if (requestedPage) return has(requestedPage) ? requestedPage : undefined;
  if (has(currentPage)) return currentPage;
  const globalPage = findGlobalPage(config);
  return globalPage && has(globalPage.key) ? globalPage.key : undefined;
}

export function findPage(config: Pick<CmsConfig, 'pages'>, pageKey: string): PageDef | undefined {
  return config.pages.find((p) => p.key === pageKey);
}
````

#### File 6 of 25: `<KIT_DIR>/core/merge.ts`

````ts
import type { PageDef, SectionDetail, SectionMetadata, SectionRecord } from './types';

function clone<T>(value: T): T {
  if (value === null || typeof value !== 'object') return value;
  return JSON.parse(JSON.stringify(value)) as T;
}

/**
 * Full content of a page: its defaults, with each saved override replacing its
 * section. Unpublished overrides are applied only when `includeDrafts` is true.
 */
export function mergePageContent<T = Record<string, unknown>>(
  page: PageDef,
  records: SectionRecord[],
  options: { includeDrafts?: boolean } = {}
): T {
  const result = clone(page.defaults) as Record<string, unknown>;
  for (const record of records) {
    if (record.page !== page.key) continue;
    if (!options.includeDrafts && !record.isPublished) continue;
    if (record.content !== null && record.content !== undefined) {
      result[record.sectionKey] = clone(record.content);
    }
  }
  return result as T;
}

/** Every editable section key of a page: its defaults' keys, then any extra declared sections. */
export function getSectionKeys(page: PageDef): string[] {
  const keys = Object.keys(page.defaults);
  for (const section of page.sections) {
    if (!keys.includes(section.key)) keys.push(section.key);
  }
  return keys;
}

/** Metadata for every editable section of the given pages. */
export function listManagedSections(pages: PageDef[], records: SectionRecord[]): SectionMetadata[] {
  const byKey = new Map<string, SectionRecord>();
  for (const record of records) byKey.set(`${record.page}\u0000${record.sectionKey}`, record);

  const list: SectionMetadata[] = [];
  for (const page of pages) {
    for (const sectionKey of getSectionKeys(page)) {
      const record = byKey.get(`${page.key}\u0000${sectionKey}`);
      list.push({
        page: page.key,
        sectionKey,
        hasCustomOverride: Boolean(record),
        isPublished: record ? record.isPublished : true,
        updatedAt: record ? record.updatedAt : null,
        updatedBy: record?.updatedBy ?? null,
      });
    }
  }
  return list;
}

/**
 * One section as the editor sees it: the saved override (draft or published) if
 * there is one, otherwise the default. Returns null for an unknown section.
 */
export function getSectionDetail<T = unknown>(
  page: PageDef,
  sectionKey: string,
  record: SectionRecord | null
): SectionDetail<T> | null {
  const hasDefault = Object.prototype.hasOwnProperty.call(page.defaults, sectionKey);
  const declared = page.sections.some((s) => s.key === sectionKey);
  if (!record && !hasDefault && !declared) return null;

  const content = record && record.content !== null && record.content !== undefined
    ? record.content
    : page.defaults[sectionKey] ?? {};

  return {
    page: page.key,
    sectionKey,
    content: clone(content) as T,
    hasCustomOverride: Boolean(record),
    isPublished: record ? record.isPublished : true,
    updatedAt: record ? record.updatedAt : null,
    updatedBy: record?.updatedBy ?? null,
  };
}
````

#### File 7 of 25: `<KIT_DIR>/core/messages.ts`

````ts
import type { FieldStyle } from './types';

/**
 * Messages exchanged between the studio (parent window) and the public page in
 * the preview iframe. Names are part of the public protocol; keep them stable.
 */
export const CMS_MESSAGE = {
  /** iframe -> studio: a section's, a single field's or a record field's edit button was clicked. */
  EDIT_SECTION: 'CMS_EDIT_SECTION',
  /** studio -> iframe: scroll to and highlight a section. */
  SCROLL_TO_SECTION: 'SCROLL_TO_SECTION',
  /** studio -> iframe: show or hide the edit affordances. */
  SET_EDIT_MODE: 'SET_CMS_EDIT_MODE',
  /** studio -> iframe: unsaved form content to render immediately. */
  DRAFT_PREVIEW: 'CMS_DRAFT_PREVIEW',
  /** studio -> iframe: content was saved or reset, fetch it again. */
  CONTENT_UPDATED: 'CMS_CONTENT_UPDATED',
  /** studio -> iframe: unsaved values of a collection record, to render immediately. */
  ITEM_DRAFT: 'CMS_ITEM_DRAFT',
  /** studio -> iframe: unsaved style of one field (null clears it), to render immediately. */
  STYLE_DRAFT: 'CMS_STYLE_DRAFT',
} as const;

/** Query flag that marks a page as loaded inside the studio. */
export const PREVIEW_PARAM = 'cms_preview';
/** Query flag that turns the hover-to-edit buttons on. */
export const EDIT_MODE_PARAM = 'cms_edit_mode';

export type CmsMessage =
  | {
      type: typeof CMS_MESSAGE.EDIT_SECTION;
      sectionKey: string;
      /** Page the section belongs to, e.g. the global page for a navbar. Default: the open page. */
      page?: string;
      title?: string;
      fieldPath?: string;
      /** What the clicked field shows, found from its element: an image, or text and the rest. */
      fieldKind?: 'image' | 'icon' | 'text';
      /** Set when the field belongs to a collection record instead of a section. */
      collection?: string;
      item?: string;
    }
  | { type: typeof CMS_MESSAGE.SCROLL_TO_SECTION; sectionKey: string }
  | { type: typeof CMS_MESSAGE.SET_EDIT_MODE; enabled: boolean }
  | { type: typeof CMS_MESSAGE.DRAFT_PREVIEW; page: string; sectionKey: string; draftContent: unknown }
  | { type: typeof CMS_MESSAGE.CONTENT_UPDATED }
  | { type: typeof CMS_MESSAGE.ITEM_DRAFT; collection: string; item: string; values: Record<string, unknown> | null }
  | { type: typeof CMS_MESSAGE.STYLE_DRAFT; page: string; sectionKey: string; path: string; style: FieldStyle | null };

const MESSAGE_TYPES = new Set<string>(Object.values(CMS_MESSAGE));

export function isCmsMessage(data: unknown): data is CmsMessage {
  return (
    typeof data === 'object' &&
    data !== null &&
    typeof (data as { type?: unknown }).type === 'string' &&
    MESSAGE_TYPES.has((data as { type: string }).type)
  );
}

/** Origin of a URL, or null when it cannot be parsed. */
export function originOf(url: string | undefined | null, base?: string): string | null {
  if (!url) return null;
  try {
    return new URL(url, base).origin;
  } catch {
    return null;
  }
}

/** The current window's origin plus any extra allowed origins, de-duplicated. */
export function trustedOrigins(extra: (string | null | undefined)[] = []): string[] {
  const set = new Set<string>();
  if (typeof window !== 'undefined') set.add(window.location.origin);
  for (const value of extra) {
    const origin = originOf(value ?? undefined);
    if (origin) set.add(origin);
  }
  return Array.from(set);
}

/**
 * Send a message to another window, once per trusted origin. The browser drops
 * the copies whose origin does not match the target, so content never leaks to
 * an unexpected page (unlike posting with "*").
 */
export function postCmsMessage(target: Window | null | undefined, message: CmsMessage, origins: string[]): void {
  if (!target) return;
  // Clone so the receiver never shares references with the sender's state.
  const payload = JSON.parse(JSON.stringify(message)) as CmsMessage;
  for (const origin of origins) {
    try {
      target.postMessage(payload, origin);
    } catch {
      // Ignore invalid origins.
    }
  }
}

/** Subscribe to CMS messages from trusted origins (and optionally one source window). */
export function listenForCmsMessages(
  handler: (message: CmsMessage, event: MessageEvent) => void,
  options: { origins: string[]; source?: () => Window | null | undefined }
): () => void {
  if (typeof window === 'undefined') return () => undefined;
  const listener = (event: MessageEvent) => {
    if (!options.origins.includes(event.origin)) return;
    if (options.source) {
      const expected = options.source();
      if (expected && event.source !== expected) return;
    }
    if (!isCmsMessage(event.data)) return;
    handler(event.data, event);
  };
  window.addEventListener('message', listener);
  return () => window.removeEventListener('message', listener);
}
````

#### File 8 of 25: `<KIT_DIR>/core/paths.ts`

````ts
import { EDIT_MODE_PARAM, PREVIEW_PARAM } from './messages';

/** "items.0.title" becomes ["items", 0, "title"]. */
export function parseFieldPath(path: string): (string | number)[] {
  return path.split('.').map((part) => (/^\d+$/.test(part) ? Number(part) : part));
}

/** The value at a field path, or undefined. Only the content's own values can be reached. */
export function getAtPath(data: unknown, path: (string | number)[]): unknown {
  let current = data;
  for (const part of path) {
    if (current === null || typeof current !== 'object') return undefined;
    if (Array.isArray(current) && typeof part !== 'number') return undefined;
    if (!Object.prototype.hasOwnProperty.call(current, part)) return undefined;
    current = (current as Record<string | number, unknown>)[part];
  }
  return current;
}

/** Absolute public URL of a route, using `publicSiteUrl` when the site runs on another origin. */
export function publicUrl(route: string, publicSiteUrl?: string): string {
  if (!publicSiteUrl) return route;
  return `${publicSiteUrl.replace(/\/+$/, '')}${route.startsWith('/') ? route : `/${route}`}`;
}

/** URL loaded in the studio's preview iframe. */
export function buildPreviewUrl(
  route: string,
  options: { publicSiteUrl?: string; editMode?: boolean; cacheBust?: number | string } = {}
): string {
  const base = publicUrl(route, options.publicSiteUrl);
  const params = [`${PREVIEW_PARAM}=1`];
  if (options.editMode) params.push(`${EDIT_MODE_PARAM}=1`);
  if (options.cacheBust !== undefined) params.push(`t=${encodeURIComponent(String(options.cacheBust))}`);
  return `${base}${base.includes('?') ? '&' : '?'}${params.join('&')}`;
}
````

#### File 9 of 25: `<KIT_DIR>/core/styles.ts`

````ts
import type { CmsConfig, FieldStyle, StyleProps, StyleSheetData } from './types';

/**
 * Field styles: the look of one field (colour, size, spacing...) set in the studio's Style tab.
 * A page's styles are one record, { page, sectionKey: "_styles", content: StyleSheetData }, saved
 * through the normal storage adapter, so they reach the site with the page content.
 */
export const STYLES_KEY = '_styles';

/** Default widths at which the tablet and phone values take over. */
export const DEFAULT_BREAKPOINTS = { tablet: 1024, phone: 768 } as const;

/** Every style property the Style tab can set, mapped to its CSS name. */
const CSS_NAMES: Record<keyof StyleProps, string> = {
  color: 'color',
  fontSize: 'font-size',
  fontWeight: 'font-weight',
  lineHeight: 'line-height',
  letterSpacing: 'letter-spacing',
  textAlign: 'text-align',
  fontFamily: 'font-family',
  marginTop: 'margin-top',
  marginRight: 'margin-right',
  marginBottom: 'margin-bottom',
  marginLeft: 'margin-left',
  paddingTop: 'padding-top',
  paddingRight: 'padding-right',
  paddingBottom: 'padding-bottom',
  paddingLeft: 'padding-left',
  width: 'width',
  maxWidth: 'max-width',
  height: 'height',
  backgroundColor: 'background-color',
  borderRadius: 'border-radius',
  borderWidth: 'border-width',
  borderColor: 'border-color',
  objectFit: 'object-fit',
  objectPosition: 'object-position',
  aspectRatio: 'aspect-ratio',
  opacity: 'opacity',
};

export const STYLE_PROPERTIES = Object.keys(CSS_NAMES) as (keyof StyleProps)[];

/** Properties that only work on a box, so a wrapper <span> needs display: inline-block for them. */
const BOX_PROPERTIES: (keyof StyleProps)[] = [
  'width', 'maxWidth', 'height', 'aspectRatio', 'marginTop', 'marginBottom', 'paddingTop', 'paddingBottom',
  'backgroundColor', 'borderRadius', 'borderWidth',
];

/** Image properties that must be set on the <img> itself when the field's element is a wrapper. */
const IMAGE_INNER: (keyof StyleProps)[] = ['objectFit', 'objectPosition'];

/** Characters that could end the declaration or the <style> element. Editors type these values. */
const UNSAFE = /[;{}<>\\\r\n]/;

/** Id of a field in the data-cms-style attribute and in its CSS selector. */
export function styleId(page: string, section: string, path: string): string {
  return `${page}:${section}:${path}`;
}

/**
 * Properties that take a length. A plain number typed there ("50") means pixels, because CSS
 * ignores a length without a unit. Line height, weight, opacity and aspect ratio stay unitless.
 */
const LENGTH_PROPERTIES = new Set<keyof StyleProps>([
  'fontSize', 'letterSpacing', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft',
  'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'width', 'maxWidth', 'height',
  'borderRadius', 'borderWidth',
]);

/** Keep only known properties with safe, non-empty string values. */
export function sanitizeStyleProps(props: unknown): StyleProps {
  const out: StyleProps = {};
  if (!props || typeof props !== 'object') return out;
  for (const [key, value] of Object.entries(props)) {
    if (!(key in CSS_NAMES)) continue;
    if (typeof value !== 'string' && typeof value !== 'number') continue;
    const text = String(value).trim();
    if (!text || UNSAFE.test(text)) continue;
    const isBareNumber = /^-?\d*\.?\d+$/.test(text) && Number(text) !== 0;
    out[key as keyof StyleProps] = isBareNumber && LENGTH_PROPERTIES.has(key as keyof StyleProps) ? `${text}px` : text;
  }
  return out;
}

/** True when the field has at least one usable value on any device. */
export function hasFieldStyle(style: FieldStyle | undefined | null): boolean {
  if (!style) return false;
  return (['desktop', 'tablet', 'phone'] as const).some((d) => Object.keys(sanitizeStyleProps(style[d])).length > 0);
}

/**
 * `boxed`: the element is inline (the <span> added around the field, or an inline element such as
 * <span> or <a>), so it needs a box for size, spacing, background and corners (inline-block), and a
 * full line for alignment (block).
 */
function declarations(props: StyleProps, boxed: boolean, skip: (keyof StyleProps)[] = []): string {
  let css = '';
  for (const key of STYLE_PROPERTIES) {
    const value = props[key];
    if (value === undefined || skip.includes(key)) continue;
    css += `${CSS_NAMES[key]}:${value};`;
    if (key === 'borderWidth') css += 'border-style:solid;';
  }
  if (boxed && props.textAlign !== undefined && !skip.includes('textAlign')) css += 'display:block;';
  else if (boxed && BOX_PROPERTIES.some((key) => props[key] !== undefined && !skip.includes(key))) css += 'display:inline-block;';
  return css;
}

/** Inline HTML elements: a style on one of them needs a box (see declarations). */
export const INLINE_TAGS = new Set([
  'span', 'a', 'strong', 'em', 'b', 'i', 'u', 's', 'small', 'label', 'abbr', 'cite', 'code', 'mark',
  'q', 'sub', 'sup', 'time',
]);

/** Fonts served by Fontshare instead of Google Fonts (their CSS API names). */
const FONTSHARE: Record<string, string> = {
  'Clash Display': 'clash-display',
  'Cabinet Grotesk': 'cabinet-grotesk',
  Satoshi: 'satoshi',
  'General Sans': 'general-sans',
};

/** The stylesheet that loads a font chosen in the Style tab, or null for a value it cannot load. */
export function fontStylesheetUrl(fontFamily: string): string | null {
  const name = fontFamily.split(',')[0].trim().replace(/^["']|["']$/g, '');
  if (!/^[A-Za-z0-9 ]{1,60}$/.test(name)) return null;
  if (FONTSHARE[name]) return `https://api.fontshare.com/v2/css?f[]=${FONTSHARE[name]}@300,400,500,600,700&display=swap`;
  return `https://fonts.googleapis.com/css2?family=${name.trim().replace(/ +/g, '+')}&display=swap`;
}

/** Every font a field style uses, on any device. */
export function fieldStyleFonts(style: FieldStyle | undefined | null): string[] {
  if (!style) return [];
  const fonts = (['desktop', 'tablet', 'phone'] as const)
    .map((d) => sanitizeStyleProps(style[d]).fontFamily)
    .filter((f): f is string => !!f);
  return Array.from(new Set(fonts));
}

/**
 * Rules for an image inside a wrapper: the wrapper takes size, corners, border and spacing and
 * clips the image (so rounded corners cut it); the <img> fills a sized wrapper and takes fit and
 * focus. Returns [wrapper declarations, img declarations].
 */
function imageWrapperDeclarations(props: StyleProps): [string, string] {
  let outer = declarations(props, true, IMAGE_INNER);
  // No gap under the image (inline-block boxes sit on the text baseline).
  if (outer.includes('display:inline-block;')) outer += 'vertical-align:top;';
  if (props.borderRadius !== undefined) outer += 'overflow:hidden;';
  // A ratio without a width: the box takes the full width, so the ratio has a side to work from.
  if (props.aspectRatio !== undefined && props.width === undefined && props.maxWidth === undefined) {
    outer = outer.replace('display:inline-block;', 'display:block;');
    outer += 'width:100%;';
  }
  if (props.aspectRatio !== undefined && props.height === undefined) outer += 'height:auto;';
  let inner = '';
  if (props.width !== undefined || props.maxWidth !== undefined || props.aspectRatio !== undefined) inner += 'width:100%;';
  if (props.height !== undefined || props.aspectRatio !== undefined) inner += 'height:100%;';
  for (const key of IMAGE_INNER) if (props[key] !== undefined) inner += `${CSS_NAMES[key]}:${props[key]};`;
  if (props.borderRadius !== undefined) inner += `border-radius:${props.borderRadius};`;
  return [outer, inner];
}

/**
 * CSS for one field: the desktop rules, then media blocks for tablet and phone. The attribute is
 * repeated in the selector (specificity 0,2,0) so the rules win over single utility classes.
 * `wrapper`: the element is the <span> CmsField added, which needs inline-block for box values.
 * `inline`: the field's own element is inline (<span>, <a>...), which needs the same.
 */
export function fieldStyleToCss(
  id: string,
  style: FieldStyle | undefined | null,
  options: { breakpoints?: { tablet?: number; phone?: number }; wrapper?: boolean; inline?: boolean } = {}
): string {
  if (!style) return '';
  const attr = `[data-cms-style="${id.replace(/["\\]/g, '\\$&')}"]`;
  const selector = attr + attr;
  const wrapper = options.wrapper ?? false;
  const boxed = wrapper || (options.inline ?? false);
  const tablet = options.breakpoints?.tablet ?? DEFAULT_BREAKPOINTS.tablet;
  const phone = options.breakpoints?.phone ?? DEFAULT_BREAKPOINTS.phone;
  const imageInWrapper = style.kind === 'image' && wrapper;
  const rules = (props: StyleProps): string => {
    if (style.kind === 'icon') {
      // An icon: its size is the font size, set as the <svg>'s width and height. In a wrapper, the
      // colour goes on the <svg> too (it may have a colour class of its own). On the <svg> itself,
      // padding and border grow the badge around the icon instead of shrinking the icon.
      let body = declarations(props, boxed, ['fontSize']);
      let inner = '';
      if (wrapper) {
        if (props.fontSize !== undefined) inner += `width:${props.fontSize};height:${props.fontSize};`;
        if (props.color !== undefined) inner += `color:${props.color};`;
        if (inner) inner = `${selector} svg{${inner}}`;
      } else {
        if (props.fontSize !== undefined) body += `width:${props.fontSize};height:${props.fontSize};`;
        const framed = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'borderWidth'] as const;
        if (framed.some((key) => props[key] !== undefined)) body += 'box-sizing:content-box;';
      }
      return (body ? `${selector}{${body}}` : '') + inner;
    }
    if (!imageInWrapper) {
      let body = declarations(props, boxed);
      // An aspect ratio needs one free side: without a height of its own, release the element's
      // height (a class such as h-[400px] would otherwise win over the ratio).
      if (props.aspectRatio !== undefined && props.height === undefined) body += 'height:auto;';
      return body ? `${selector}{${body}}` : '';
    }
    const [outer, inner] = imageWrapperDeclarations(props);
    return (outer ? `${selector}{${outer}}` : '') + (inner ? `${selector} img{${inner}}` : '');
  };
  let css = rules(sanitizeStyleProps(style.desktop));
  for (const [device, width] of [['tablet', tablet], ['phone', phone]] as const) {
    const body = rules(sanitizeStyleProps(style[device]));
    if (body) css += `@media (max-width:${width - 0.02}px){${body}}`;
  }
  return css;
}

/** Set (or with null, remove) one field's style, keeping every other field of the page. */
export function setFieldStyle(
  sheet: StyleSheetData | undefined | null,
  section: string,
  path: string,
  style: FieldStyle | null
): StyleSheetData {
  const next: StyleSheetData = {};
  for (const [key, fields] of Object.entries(sheet ?? {})) next[key] = { ...fields };
  if (style && hasFieldStyle(style)) {
    next[section] = { ...(next[section] ?? {}), [path]: style };
  } else if (next[section]) {
    delete next[section][path];
    if (Object.keys(next[section]).length === 0) delete next[section];
  }
  return next;
}

/** True when a URL path matches a page route; "[slug]" matches one segment. */
export function routeMatches(route: string, pathname: string): boolean {
  const clean = (p: string) => (p.length > 1 ? p.replace(/\/+$/, '') : p);
  const pattern = clean(route)
    .split('/')
    .map((part) => (/^\[[^\]]+\]$/.test(part) ? '[^/]+' : part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
    .join('/');
  return new RegExp(`^${pattern}$`).test(clean(pathname));
}

/**
 * The page a field's styles belong to: the page given on the field or its section; otherwise the
 * only page with this section key (the global page included); otherwise the page whose route
 * matches `pathname`. Undefined when it cannot be told.
 */
export function resolveFieldPage(
  config: Pick<CmsConfig, 'pages'>,
  section: string,
  explicitPage?: string,
  pathname?: string
): string | undefined {
  if (explicitPage) return explicitPage;
  const owners = config.pages.filter((p) => p.sections.some((s) => s.key === section));
  if (owners.length === 1) return owners[0].key;
  if (owners.length === 0 || !pathname) return undefined;
  const matching = owners.filter((p) => !p.global && routeMatches(p.route, pathname));
  return matching.length === 1 ? matching[0].key : undefined;
}
````

#### File 10 of 25: `<KIT_DIR>/core/theme.ts`

````ts
/**
 * Turn a theme section ({ primaryColor: "#7c3aed", headingFont: "Inter" }) into CSS variables
 * (--primary-color, --heading-font). Nested objects are joined with "-": { colors: { brand } }
 * becomes --colors-brand. Only strings and numbers are used, and values that could break out of
 * the declaration (";", "{", "}", "<", ">", "\" or a line break) are skipped, because editors type them.
 */
export function themeToCssVariables(theme: unknown, options: { prefix?: string } = {}): Record<string, string> {
  const prefix = options.prefix ?? '--';
  const out: Record<string, string> = {};
  const walk = (value: unknown, name: string[]) => {
    if (typeof value === 'string' || typeof value === 'number') {
      const text = String(value).trim();
      if (!text || /[;{}<>\\\r\n]/.test(text)) return;
      const key = name.map(toKebab).filter(Boolean).join('-');
      if (/^[a-z0-9-]+$/.test(key)) out[prefix + key] = text;
      return;
    }
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      for (const [key, inner] of Object.entries(value)) walk(inner, [...name, key]);
    }
  };
  walk(theme, []);
  return out;
}

/** CSS text for a theme section: `:root{--primary-color:#7c3aed;}`. Use `selector` for a scope other than :root. */
export function themeToCss(theme: unknown, options: { prefix?: string; selector?: string } = {}): string {
  const vars = themeToCssVariables(theme, options);
  const body = Object.entries(vars)
    .map(([key, value]) => `${key}:${value};`)
    .join('');
  return body ? `${options.selector ?? ':root'}{${body}}` : '';
}

function toKebab(part: string): string {
  return part
    .replace(/([a-z0-9])([A-Z])/g, '$1-$2')
    .replace(/[_\s]+/g, '-')
    .toLowerCase();
}

/** True when a form field holds a colour: a hex value, or a name ending in "color"/"colour". */
export function isColorField(fieldName: string, value: unknown): boolean {
  if (typeof value !== 'string') return false;
  if (/^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(value.trim())) return true;
  return /colou?r$/i.test(fieldName) && (value === '' || /^#/.test(value.trim()));
}

/** True when a form field picks one of the site's fonts (`fonts` in defineCms). */
export function isFontField(fieldName: string, value: unknown, fonts: string[] | undefined): boolean {
  return !!fonts?.length && typeof value === 'string' && /font$/i.test(fieldName);
}
````

#### File 11 of 25: `<KIT_DIR>/core/collections.ts`

````ts
import type { CmsConfig, CollectionItemSummary, PageDef } from './types';

const BRACKET = /\[(?:\.\.\.)?([A-Za-z0-9_]+)\]/g;

/** True for routes with a [param] segment, such as "/blog/[slug]". */
export function isDynamicRoute(route: string): boolean {
  return /\[[^\]]+\]/.test(route);
}

/**
 * The public URL of one record: each [name] in the route is replaced by `item.params[name]`,
 * or by the id when there is no such param. "/blog/[slug]" + { id: "school" } -> "/blog/school".
 */
export function fillRoute(route: string, item: Pick<CollectionItemSummary, 'id' | 'params'>): string {
  return route.replace(BRACKET, (_, name: string) => encodeURIComponent(item.params?.[name] ?? item.id));
}

/** Pages shown in the studio's page menu: every page that does not belong to a parent page. */
export function topLevelPages(config: Pick<CmsConfig, 'pages'>): PageDef[] {
  return config.pages.filter((p) => !p.parent);
}

/** The top-level page a page is listed under (itself when it has no parent). */
export function groupPageOf(config: Pick<CmsConfig, 'pages'>, page: PageDef): PageDef {
  return (page.parent && config.pages.find((p) => p.key === page.parent)) || page;
}

/**
 * The pages whose records appear in the record menu of a top-level page: its children with a
 * collection, plus the page itself when it shows records.
 */
export function recordPagesOf(config: Pick<CmsConfig, 'pages'>, group: PageDef): PageDef[] {
  const children = config.pages.filter((p) => p.parent === group.key && p.collection);
  return group.collection ? [group, ...children] : children;
}
````

#### File 12 of 25: `<KIT_DIR>/adapters/rest.ts`

````ts
import type { CmsStorageAdapter, CollectionItemSummary, ListOptions, MediaItem, SaveRecordInput, SectionRecord } from '../core/types';

export interface RestAdapterOptions {
  /** Base URL of the CMS API, e.g. "/api/cms" or "https://api.example.com/cms". */
  baseUrl: string;
  /** Extra request headers (for example an Authorization header), or a function returning them. */
  headers?: HeadersInit | (() => HeadersInit | Promise<HeadersInit>);
  /** Fetch credentials mode. Defaults to "same-origin" so session cookies are sent. */
  credentials?: RequestCredentials;
  /** Set to false when the server does not implement the /media endpoints. */
  media?: boolean;
  /** Custom fetch implementation (tests, polyfills). */
  fetch?: typeof fetch;
}

/** Error thrown for non-2xx responses; carries the HTTP status. */
export class CmsRequestError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
    this.name = 'CmsRequestError';
  }
}

const enc = encodeURIComponent;

/**
 * Adapter that talks to a CMS HTTP API. The contract (implemented by
 * `createCmsRouteHandler` and documented in the README):
 *
 *   GET    {base}/records?page=&drafts=1     -> SectionRecord[]
 *   GET    {base}/records/:page/:section     -> SectionRecord, or null when never edited
 *   PUT    {base}/records/:page/:section     body { content, isPublished } -> SectionRecord
 *   DELETE {base}/records/:page/:section     -> 204
 *   GET    {base}/media                      -> MediaItem[]
 *   POST   {base}/media                      multipart "files" -> { items: MediaItem[] }
 *   GET    {base}/collections/:c/items       -> CollectionItemSummary[]
 *   GET    {base}/collections/:c/items/:id   -> the record's editable values (404 when missing)
 *   PUT    {base}/collections/:c/items/:id   body { values } -> the record's values after saving
 */
export function restAdapter(options: RestAdapterOptions): CmsStorageAdapter {
  const base = options.baseUrl.replace(/\/+$/, '');
  const doFetch = options.fetch ?? ((...args: Parameters<typeof fetch>) => fetch(...args));

  async function request<T>(path: string, init: RequestInit = {}, allow404 = false): Promise<T | null> {
    const extra = typeof options.headers === 'function' ? await options.headers() : options.headers;
    const headers = new Headers(extra);
    if (!headers.has('Accept')) headers.set('Accept', 'application/json');
    if (init.body && typeof init.body === 'string' && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }

    const res = await doFetch(`${base}${path}`, {
      ...init,
      headers,
      credentials: options.credentials ?? 'same-origin',
      cache: 'no-store',
    });

    if (allow404 && res.status === 404) return null;
    if (!res.ok) {
      let message = `Request failed with status ${res.status}`;
      try {
        const body = (await res.json()) as { detail?: string; error?: string };
        message = body.detail || body.error || message;
      } catch {
        // Non-JSON error body.
      }
      throw new CmsRequestError(message, res.status);
    }
    if (res.status === 204) return null;
    return (await res.json()) as T;
  }

  const draftsQuery = (opts?: ListOptions) => (opts?.includeDrafts ? 'drafts=1' : '');

  const adapter: CmsStorageAdapter = {
    async listRecords(page?: string, opts?: ListOptions) {
      const params = [page ? `page=${enc(page)}` : '', draftsQuery(opts)].filter(Boolean).join('&');
      const data = await request<SectionRecord[]>(`/records${params ? `?${params}` : ''}`);
      return Array.isArray(data) ? data : [];
    },

    async getRecord(page: string, sectionKey: string, opts?: ListOptions) {
      const q = draftsQuery(opts);
      return request<SectionRecord>(`/records/${enc(page)}/${enc(sectionKey)}${q ? `?${q}` : ''}`, {}, true);
    },

    async saveRecord(input: SaveRecordInput) {
      const data = await request<SectionRecord>(`/records/${enc(input.page)}/${enc(input.sectionKey)}`, {
        method: 'PUT',
        body: JSON.stringify({ content: input.content, isPublished: input.isPublished }),
      });
      if (!data) throw new CmsRequestError('Empty response from server', 500);
      return data;
    },

    async deleteRecord(page: string, sectionKey: string) {
      await request(`/records/${enc(page)}/${enc(sectionKey)}`, { method: 'DELETE' }, true);
    },

    async listItems(collection: string) {
      const data = await request<CollectionItemSummary[]>(`/collections/${enc(collection)}/items`);
      return Array.isArray(data) ? data : [];
    },

    async getItem(collection: string, id: string) {
      return request<Record<string, unknown>>(`/collections/${enc(collection)}/items/${enc(id)}`, {}, true);
    },

    async saveItem(collection: string, id: string, values: Record<string, unknown>) {
      const data = await request<Record<string, unknown>>(`/collections/${enc(collection)}/items/${enc(id)}`, {
        method: 'PUT',
        body: JSON.stringify({ values }),
      });
      if (!data) throw new CmsRequestError('Empty response from server', 500);
      return data;
    },
  };

  if (options.media !== false) {
    adapter.listMedia = async () => {
      const data = await request<MediaItem[]>('/media');
      return Array.isArray(data) ? data : [];
    };
    adapter.uploadMedia = async (files: File[]) => {
      const form = new FormData();
      files.forEach((file) => form.append('files', file));
      const data = await request<{ items: MediaItem[] }>('/media', { method: 'POST', body: form });
      return data?.items ?? [];
    };
  }

  return adapter;
}
````

#### File 13 of 25: `<KIT_DIR>/adapters/django.ts`

````ts
import type { CmsStorageAdapter } from '../core/types';
import { restAdapter, type RestAdapterOptions } from './rest';

export interface DjangoAdapterOptions extends Omit<RestAdapterOptions, 'headers'> {
  /** Extra headers, e.g. an Authorization header if your AUTHORIZE check uses tokens. */
  headers?: Record<string, string> | (() => Record<string, string> | Promise<Record<string, string>>);
}

const UNSAFE = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/**
 * Adapter for Storio's /api/cms/ API. Same API as `restAdapter`, plus
 * Django's CSRF handling: it fetches a token from `{baseUrl}/csrf`, sends it as
 * `X-CSRFToken` on writes, and refreshes it once if Django rejects it.
 *
 * Cookies are sent with every request (`credentials: "include"` by default) so
 * Django's session login identifies the editor, even on another domain.
 */
export function djangoAdapter(options: DjangoAdapterOptions): CmsStorageAdapter {
  const base = options.baseUrl.replace(/\/+$/, '');
  const credentials = options.credentials ?? 'include';
  const baseFetch = options.fetch ?? ((...args: Parameters<typeof fetch>) => fetch(...args));
  let token: Promise<string> | null = null;

  const extraHeaders = async () =>
    typeof options.headers === 'function' ? await options.headers() : options.headers ?? {};

  const getToken = (refresh = false): Promise<string> => {
    if (!token || refresh) {
      token = (async () => {
        const res = await baseFetch(`${base}/csrf`, {
          credentials,
          headers: { Accept: 'application/json', ...(await extraHeaders()) },
          cache: 'no-store',
        });
        if (!res.ok) throw new Error(`Could not get a CSRF token (status ${res.status})`);
        const body = (await res.json()) as { csrfToken?: string };
        return body.csrfToken ?? '';
      })().catch((err) => {
        token = null; // let the next write try again
        throw err;
      });
    }
    return token;
  };

  const csrfFetch = (async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const method = (init.method ?? 'GET').toUpperCase();
    if (!UNSAFE.has(method)) return baseFetch(input, init);

    const send = async (refresh: boolean) => {
      const headers = new Headers(init.headers);
      headers.set('X-CSRFToken', await getToken(refresh));
      return baseFetch(input, { ...init, headers });
    };

    const res = await send(false);
    // A stale token (e.g. after login rotated it) gives 403: refresh once and retry.
    return res.status === 403 ? send(true) : res;
  }) as typeof fetch;

  return restAdapter({
    ...options,
    credentials,
    headers: extraHeaders,
    fetch: csrfFetch,
  });
}
````

#### File 14 of 25: `<KIT_DIR>/server/getPageContent.ts`

````ts
import type { Metadata } from 'next';
import type { CmsConfig, CmsStorageAdapter } from '../core/types';
import { findGlobalPage, findPage } from '../core/defineCms';
import { mergePageContent } from '../core/merge';

/** Shape of the optional "seo" section a page can define in its defaults. */
export interface PageSeoConfig {
  title?: string;
  description?: string;
  keywords?: string | string[];
  canonical?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterCard?: 'summary' | 'summary_large_image';
  /** e.g. "index, follow" or "noindex, nofollow". */
  robots?: string;
}

/** Shape of the optional "seo" section of the global page: site-wide defaults. */
export interface SiteSeoConfig extends PageSeoConfig {
  /** Site name, e.g. "Brainicon". Used for og:site_name and as the title when a page has none. */
  siteName?: string;
  /** Title of every page, with %s for the page title, e.g. "%s | Brainicon". */
  titleTemplate?: string;
  /** Favicon URL, e.g. "/favicon.ico". */
  favicon?: string;
}

/**
 * Load a page's published content on the server (Server Components,
 * generateMetadata, getServerSideProps). Falls back to the page defaults when
 * storage is unreachable, so a storage outage never breaks rendering.
 */
export async function getPageContent<T = Record<string, unknown>>(
  config: Pick<CmsConfig, 'pages'>,
  pageKey: string,
  options: { storage: CmsStorageAdapter; includeDrafts?: boolean }
): Promise<T> {
  const page = findPage(config, pageKey);
  if (!page) throw new Error(`[storio-editor] Unknown page "${pageKey}".`);
  try {
    const records = await options.storage.listRecords(pageKey, { includeDrafts: options.includeDrafts });
    return mergePageContent<T>(page, records, { includeDrafts: options.includeDrafts });
  } catch {
    return mergePageContent<T>(page, []);
  }
}

/**
 * Load the published content of every page in the config, keyed by page key, ready
 * for `<CmsProvider initialContent={...}>`. With it, the server-rendered HTML already
 * contains the edited text (good for SEO, no flash of default content). Pages whose
 * storage cannot be reached fall back to their defaults.
 */
export async function getAllPageContent(
  config: Pick<CmsConfig, 'pages'>,
  options: { storage: CmsStorageAdapter }
): Promise<Record<string, Record<string, unknown>>> {
  const entries = await Promise.all(
    config.pages.map(async (page) => [page.key, await getPageContent<Record<string, unknown>>(config, page.key, options)] as const)
  );
  return Object.fromEntries(entries);
}

/** Build Next.js metadata from a page's editable "seo" section, on top of a fallback. */
export function buildPageMetadata(content: { seo?: PageSeoConfig } | Record<string, unknown>, fallback: Metadata = {}): Metadata {
  const seo = (content as { seo?: PageSeoConfig }).seo;
  if (!seo || typeof seo !== 'object') return fallback;

  const keywords = Array.isArray(seo.keywords)
    ? seo.keywords
    : typeof seo.keywords === 'string'
      ? seo.keywords.split(',').map((k) => k.trim()).filter(Boolean)
      : fallback.keywords;

  // "noindex" contains "index", so test for the negative forms explicitly.
  const robots = (seo.robots ?? '').toLowerCase();
  const index = !/\bnoindex\b/.test(robots);
  const follow = !/\bnofollow\b/.test(robots);
  const fallbackTitle = typeof fallback.title === 'string' ? fallback.title : undefined;

  return {
    ...fallback,
    title: seo.title || fallback.title,
    description: seo.description || fallback.description,
    keywords,
    alternates: seo.canonical ? { ...fallback.alternates, canonical: seo.canonical } : fallback.alternates,
    openGraph: {
      ...fallback.openGraph,
      title: seo.ogTitle || seo.title || fallbackTitle,
      description: seo.ogDescription || seo.description || fallback.description || undefined,
      url: seo.canonical || (fallback.openGraph?.url as string | undefined),
      images: seo.ogImage ? [{ url: seo.ogImage }] : fallback.openGraph?.images,
    },
    twitter: {
      ...fallback.twitter,
      card: seo.twitterCard || 'summary_large_image',
      title: seo.ogTitle || seo.title || fallbackTitle,
      description: seo.ogDescription || seo.description || fallback.description || undefined,
      images: seo.ogImage ? [seo.ogImage] : fallback.twitter?.images,
    },
    robots: seo.robots ? { index, follow } : fallback.robots,
  };
}

/**
 * Build the site-wide metadata for the root layout from the global page's "seo" section:
 * a title template, the default description and share image, og:site_name and the favicon.
 */
export function buildSiteMetadata(seo: SiteSeoConfig | undefined, fallback: Metadata = {}): Metadata {
  if (!seo || typeof seo !== 'object') return fallback;
  const page = buildPageMetadata({ seo }, fallback);
  const defaultTitle = seo.title || seo.siteName || (typeof fallback.title === 'string' ? fallback.title : undefined);
  const template = seo.titleTemplate && seo.titleTemplate.includes('%s') ? seo.titleTemplate : undefined;
  return {
    ...page,
    title: template && defaultTitle ? { default: defaultTitle, template } : defaultTitle ?? fallback.title,
    openGraph: {
      ...page.openGraph,
      title: seo.ogTitle || defaultTitle,
      siteName: seo.siteName || (fallback.openGraph?.siteName as string | undefined),
    },
    twitter: { ...page.twitter, title: seo.ogTitle || defaultTitle },
    icons: seo.favicon ? { icon: seo.favicon } : fallback.icons,
  };
}

/**
 * For `generateMetadata` in the root layout: the site-wide metadata from the global page
 * (the page with `global: true`). Without a global page it returns `fallback`.
 */
export async function getSiteMetadata(
  config: Pick<CmsConfig, 'pages'>,
  options: { storage: CmsStorageAdapter; fallback?: Metadata; section?: string }
): Promise<Metadata> {
  const globalPage = findGlobalPage(config);
  if (!globalPage) return options.fallback ?? {};
  const content = await getPageContent<Record<string, unknown>>(config, globalPage.key, { storage: options.storage });
  return buildSiteMetadata(content[options.section ?? 'seo'] as SiteSeoConfig | undefined, options.fallback);
}

/**
 * Convenience for `generateMetadata`: load the page and build its metadata. When the config has
 * a global page, its "seo" section fills what the page leaves empty (description, share image),
 * so a page without SEO of its own still gets the site defaults. Pass `site: false` to skip that.
 */
export async function getPageMetadata(
  config: Pick<CmsConfig, 'pages'>,
  pageKey: string,
  options: { storage: CmsStorageAdapter; fallback?: Metadata; site?: boolean }
): Promise<Metadata> {
  const content = await getPageContent<Record<string, unknown>>(config, pageKey, { storage: options.storage });
  let fallback = options.fallback ?? {};
  const globalPage = options.site === false ? undefined : findGlobalPage(config);
  if (globalPage && globalPage.key !== pageKey) {
    const site = await getPageContent<Record<string, unknown>>(config, globalPage.key, { storage: options.storage });
    fallback = mergeSiteFallback(site.seo as SiteSeoConfig | undefined, fallback);
  }
  return buildPageMetadata(content, fallback);
}

/**
 * Site SEO under a page's own fallback. The title is left out on purpose: the root layout's
 * title template already supplies the default title, and repeating it would show it twice.
 */
function mergeSiteFallback(seo: SiteSeoConfig | undefined, fallback: Metadata): Metadata {
  if (!seo || typeof seo !== 'object') return fallback;
  const { title: _title, ogTitle: _ogTitle, canonical: _canonical, ...rest } = seo;
  const site = buildSiteMetadata({ ...rest, title: undefined }, {});
  return {
    ...site,
    title: undefined,
    ...fallback,
    openGraph: { ...site.openGraph, title: undefined, url: undefined, ...fallback.openGraph },
    twitter: { ...site.twitter, title: undefined, ...fallback.twitter },
  };
}
````

#### File 15 of 25: `<KIT_DIR>/server/isCmsPreviewRequest.ts`

````ts
import { EDIT_MODE_PARAM, PREVIEW_PARAM } from '../core/messages';

/**
 * True when a request is the studio's preview iframe loading a public page.
 * Use it in middleware so redirects (login walls, admin-host redirects, locale
 * redirects) let the preview through:
 *
 *   if (!isCmsPreviewRequest(request, { studioPath: '/admin/cms' })) { ...redirect... }
 *
 * This only decides whether to skip a redirect; it grants no access, since the
 * page shown is the same public page any visitor can load.
 */
export function isCmsPreviewRequest(
  request: { url: string; headers: Headers },
  options: { studioPath?: string } = {}
): boolean {
  const url = new URL(request.url);
  if (url.searchParams.has(PREVIEW_PARAM) || url.searchParams.has(EDIT_MODE_PARAM)) return true;
  if (request.headers.get('sec-fetch-dest') === 'iframe') return true;
  const referer = request.headers.get('referer');
  if (options.studioPath && referer) {
    try {
      return new URL(referer).pathname.startsWith(options.studioPath);
    } catch {
      return false;
    }
  }
  return false;
}
````

#### File 16 of 25: `<KIT_DIR>/site/PencilIcon.tsx`

````tsx
'use client';

import React from 'react';

/** The editor's pencil (drawn inline, so the kit needs no icon library). */
export const PencilIcon: React.FC<{ size?: number; color?: string; strokeWidth?: number }> = ({
  size = 16,
  color = 'currentColor',
  strokeWidth = 2.5,
}) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={strokeWidth}
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    style={{ display: 'block', flexShrink: 0 }}
  >
    <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />
    <path d="m15 5 4 4" />
  </svg>
);
````

#### File 17 of 25: `<KIT_DIR>/site/preview.ts`

````ts
'use client';

import { useEffect, useState } from 'react';
import { CMS_MESSAGE, EDIT_MODE_PARAM, PREVIEW_PARAM, listenForCmsMessages } from '../core/messages';

function hasParam(name: string): boolean {
  if (typeof window === 'undefined') return false;
  return new URLSearchParams(window.location.search).has(name);
}

/** True when the current page is rendered inside the studio's preview iframe. */
export function isCmsPreview(): boolean {
  return hasParam(PREVIEW_PARAM) || hasParam(EDIT_MODE_PARAM);
}

/**
 * Whether hover-to-edit is on. Starts from the `cms_edit_mode` URL flag and then
 * follows the studio's Edit/View toggle (SET_CMS_EDIT_MODE messages).
 */
export function useCmsEditMode(origins: string[]): boolean {
  const [isEditMode, setIsEditMode] = useState(false);
  const originsKey = origins.join('|');

  useEffect(() => {
    setIsEditMode(hasParam(EDIT_MODE_PARAM));
    // Only a page that is inside an iframe can be controlled by the studio.
    if (typeof window === 'undefined' || window.parent === window) return;
    return listenForCmsMessages(
      (message) => {
        if (message.type === CMS_MESSAGE.SET_EDIT_MODE) setIsEditMode(Boolean(message.enabled));
      },
      { origins, source: () => window.parent }
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [originsKey]);

  return isEditMode;
}
````

#### File 18 of 25: `<KIT_DIR>/site/sectionContext.ts`

````ts
'use client';

import { createContext } from 'react';

export interface CmsSectionContextValue {
  sectionKey: string;
  /** Page the section belongs to when it is not the open page (e.g. the global page). */
  page?: string;
  /** True when this section shows its edit controls in the studio preview. */
  isEditMode: boolean;
  /** Origins allowed to receive preview messages. */
  origins: string[];
}

/** Lets every <CmsField> share its section's state instead of listening for messages itself. */
export const CmsSectionContext = createContext<CmsSectionContextValue | null>(null);

/** Above anything a page can reasonably use, so sticky headers never cover the edit buttons. */
export const EDIT_BUTTON_Z_INDEX = 2147483000;

type HideField = () => void;

let activeField: HideField | null = null;
const fieldHoverListeners = new Set<() => void>();

function notifyFieldHover() {
  fieldHoverListeners.forEach((listener) => listener());
}

/** Makes this field the only one showing a pencil and hides the previous one. */
export function claimFieldHover(hide: HideField) {
  if (activeField === hide) return;
  const previous = activeField;
  activeField = hide;
  previous?.();
  notifyFieldHover();
}

export function releaseFieldHover(hide: HideField) {
  if (activeField !== hide) return;
  activeField = null;
  notifyFieldHover();
}

export function isFieldHoverActive() {
  return activeField !== null;
}

export function subscribeToFieldHover(listener: () => void) {
  fieldHoverListeners.add(listener);
  return () => {
    fieldHoverListeners.delete(listener);
  };
}
````

#### File 19 of 25: `<KIT_DIR>/site/fieldStyles.ts`

````ts
'use client';

import { useEffect, useSyncExternalStore } from 'react';
import type { CmsStorageAdapter, FieldStyle, StyleSheetData } from '../core/types';
import { STYLES_KEY } from '../core/styles';
import { CMS_MESSAGE, listenForCmsMessages } from '../core/messages';
import { isCmsPreview } from './preview';

/**
 * Field styles on the site: the published "_styles" record of each page (server-rendered through
 * initialContent, or fetched once when the page was not loaded on the server), plus the unsaved
 * styles the studio sends while an editor works in the Style tab.
 */
export interface FieldStyleStore {
  get(page: string, section: string, path: string): FieldStyle | undefined;
  /** Make sure a page's styles are loaded (fetches only when the server did not provide them). */
  request(page: string): void;
  subscribe(listener: () => void): () => void;
  version(): number;
  /** Start listening to the studio. Returns the stop function. */
  connect(origins: string[]): () => void;
}

const draftKey = (page: string, section: string, path: string) => `${page}\u0000${section}\u0000${path}`;

export function createFieldStyleStore(
  adapter: CmsStorageAdapter,
  initialContent: Record<string, Record<string, unknown>>
): FieldStyleStore {
  const sheets = new Map<string, StyleSheetData>();
  const requested = new Set<string>();
  const drafts = new Map<string, FieldStyle | null>();
  const listeners = new Set<() => void>();
  let version = 0;

  for (const [page, content] of Object.entries(initialContent)) {
    const sheet = content?.[STYLES_KEY];
    if (sheet && typeof sheet === 'object') sheets.set(page, sheet as StyleSheetData);
  }

  const notify = () => {
    version += 1;
    listeners.forEach((listener) => listener());
  };

  const load = async (page: string) => {
    try {
      const record = await adapter.getRecord(page, STYLES_KEY, { includeDrafts: isCmsPreview() });
      const content = record?.content;
      sheets.set(page, content && typeof content === 'object' ? (content as StyleSheetData) : {});
      notify();
    } catch {
      // Keep what we have; styles are decoration, never a reason to break the page.
    }
  };

  return {
    get(page, section, path) {
      const key = draftKey(page, section, path);
      if (drafts.has(key)) return drafts.get(key) ?? undefined;
      return sheets.get(page)?.[section]?.[path];
    },
    request(page) {
      if (requested.has(page)) return;
      requested.add(page);
      // Content loaded on the server already carries the page's styles (or their absence).
      if (Object.prototype.hasOwnProperty.call(initialContent, page)) return;
      void load(page);
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    version: () => version,
    connect(origins) {
      if (typeof window === 'undefined' || window.parent === window || origins.length === 0) return () => undefined;
      return listenForCmsMessages(
        (message) => {
          if (message.type === CMS_MESSAGE.STYLE_DRAFT) {
            drafts.set(draftKey(message.page, message.sectionKey, message.path), message.style);
            notify();
          } else if (message.type === CMS_MESSAGE.CONTENT_UPDATED) {
            drafts.clear();
            const pages = new Set([...requested, ...sheets.keys()]);
            if (pages.size === 0) notify();
            pages.forEach((page) => void load(page));
          }
        },
        { origins, source: () => window.parent }
      );
    },
  };
}

/** The current style of one field, following drafts from the studio. */
export function useStoredFieldStyle(store: FieldStyleStore, page: string | undefined, section: string, path: string): FieldStyle | undefined {
  useEffect(() => {
    if (page) store.request(page);
  }, [store, page]);
  useSyncExternalStore(store.subscribe, store.version, store.version);
  return page ? store.get(page, section, path) : undefined;
}
````

#### File 20 of 25: `<KIT_DIR>/site/itemDrafts.ts`

````ts
'use client';

import { useEffect, useSyncExternalStore } from 'react';
import { CMS_MESSAGE, listenForCmsMessages } from '../core/messages';
import { useCmsContext } from './CmsProvider';

/**
 * Unsaved values of collection records sent by the studio while an editor types. One listener
 * serves every field on the page.
 */
const drafts = new Map<string, Record<string, unknown>>();
const listeners = new Set<() => void>();
let stopListening: (() => void) | null = null;
let listeningFor = '';

const keyOf = (collection: string, item: string) => `${collection}\u0000${item}`;

function notify() {
  listeners.forEach((listener) => listener());
}

function ensureListening(origins: string[]) {
  if (typeof window === 'undefined' || window.parent === window || origins.length === 0) return;
  const key = origins.join('|');
  if (key === listeningFor) return;
  stopListening?.();
  listeningFor = key;
  stopListening = listenForCmsMessages(
    (message) => {
      if (message.type !== CMS_MESSAGE.ITEM_DRAFT) return;
      const draftKey = keyOf(message.collection, String(message.item));
      if (message.values) drafts.set(draftKey, message.values);
      else drafts.delete(draftKey);
      notify();
    },
    { origins, source: () => window.parent }
  );
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** The unsaved values the studio sent for one record, or undefined. */
export function useItemDraft(collection: string, item: string): Record<string, unknown> | undefined {
  const { origins } = useCmsContext();
  const originsKey = origins.join('|');
  useEffect(() => {
    ensureListening(origins);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [originsKey]);
  return useSyncExternalStore(
    subscribe,
    () => drafts.get(keyOf(collection, item)),
    () => undefined
  );
}

/**
 * A collection record as the page should show it: the values you loaded (from your database
 * or API), with the editor's unsaved changes laid over them while the studio preview is open.
 * Visitors always get `values` unchanged.
 *
 *   const post = useCollectionItem('blog', props.post.slug, props.post);
 */
export function useCollectionItem<T extends Record<string, unknown>>(collection: string, item: string | number, values: T): T {
  const draft = useItemDraft(collection, String(item));
  return draft ? ({ ...values, ...draft } as T) : values;
}
````

#### File 21 of 25: `<KIT_DIR>/site/CmsProvider.tsx`

````tsx
'use client';

import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { CmsConfig } from '../core/types';
import { findGlobalPage, findPage } from '../core/defineCms';
import { mergePageContent } from '../core/merge';
import { CMS_MESSAGE, listenForCmsMessages, trustedOrigins } from '../core/messages';
import { isCmsPreview } from './preview';
import { createFieldStyleStore, type FieldStyleStore } from './fieldStyles';

interface CmsContextValue {
  config: CmsConfig;
  /** Server-rendered content per page key, used before the client fetch completes. */
  initialContent: Record<string, Record<string, unknown>>;
  /** Origins allowed to send preview messages to this page. */
  origins: string[];
  /** Field styles (Style tab), published and unsaved. */
  styles: FieldStyleStore;
}

const CmsContext = createContext<CmsContextValue | null>(null);

export interface CmsProviderProps {
  config: CmsConfig;
  /**
   * Content already loaded on the server (e.g. with `getPageContent` from
   * "@/lib/storio-editor/server"), keyed by page key. Avoids a flash of default content.
   */
  initialContent?: Record<string, Record<string, unknown>>;
  children: React.ReactNode;
}

/** Makes the CMS configuration available to `usePageContent` and `CmsSection`. */
export const CmsProvider: React.FC<CmsProviderProps> = ({ config, initialContent, children }) => {
  const [origins, setOrigins] = useState<string[]>([]);

  // window is only available after mount; computing origins here keeps SSR output stable.
  useEffect(() => {
    setOrigins(trustedOrigins(config.allowedOrigins ?? []));
  }, [config.allowedOrigins]);

  // One store per provider; it reads the "_styles" record of each page from initialContent.
  const styles = useMemo(() => createFieldStyleStore(config.adapter, initialContent ?? {}), [config.adapter, initialContent]);
  const originsKey = origins.join('|');
  useEffect(() => styles.connect(origins), [styles, originsKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const value = useMemo<CmsContextValue>(
    () => ({ config, initialContent: initialContent ?? {}, origins, styles }),
    [config, initialContent, origins, styles]
  );

  return <CmsContext.Provider value={value}>{children}</CmsContext.Provider>;
};

export function useCmsContext(): CmsContextValue {
  const ctx = useContext(CmsContext);
  if (!ctx) {
    throw new Error('[storio-editor] Wrap your site in <CmsProvider config={...}> before using CMS hooks.');
  }
  return ctx;
}

/** The CMS configuration passed to the nearest CmsProvider. */
export function useCmsConfig(): CmsConfig {
  return useCmsContext().config;
}

/**
 * Live content for a page: defaults overlaid by published overrides. Inside the
 * studio preview it also applies unsaved edits as you type and refetches after a save.
 */
export function usePageContent<T = Record<string, any>>(
  pageKey: string,
  options: {
    /** Content loaded on the server for this page (e.g. with `getPageContent`). */
    initialData?: T;
  } = {}
): T {
  const { config, initialContent, origins } = useCmsContext();
  const page = findPage(config, pageKey);
  if (!page) {
    throw new Error(`[storio-editor] Unknown page "${pageKey}". Add it to the "pages" array of your CMS config.`);
  }

  const [content, setContent] = useState<T>(
    () =>
      options.initialData ??
      (initialContent[pageKey] as T | undefined) ??
      mergePageContent<T>(page, [])
  );
  const originsKey = origins.join('|');

  useEffect(() => {
    let isMounted = true;
    // In the studio preview, ask for drafts too; the server only returns them to authorised users.
    const includeDrafts = isCmsPreview();

    const fetchPage = async () => {
      try {
        const records = await config.adapter.listRecords(pageKey, { includeDrafts });
        if (isMounted) setContent(mergePageContent<T>(page, records, { includeDrafts }));
      } catch {
        // Keep the current content (defaults or server-rendered) when storage is unreachable.
      }
    };

    fetchPage();

    if (typeof window === 'undefined' || window.parent === window || origins.length === 0) {
      return () => {
        isMounted = false;
      };
    }

    const unsubscribe = listenForCmsMessages(
      (message) => {
        if (message.type === CMS_MESSAGE.CONTENT_UPDATED) {
          fetchPage();
        } else if (message.type === CMS_MESSAGE.DRAFT_PREVIEW && message.page === pageKey) {
          // Real-time draft preview inside the studio without touching storage or live visitors.
          setContent((prev) => ({
            ...(prev as Record<string, unknown>),
            [message.sectionKey]: message.draftContent,
          }) as T);
        }
      },
      { origins, source: () => window.parent }
    );

    return () => {
      isMounted = false;
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageKey, config.adapter, originsKey]);

  return content;
}

/**
 * Live content of the global page (the one with `global: true`): header, footer, contact details,
 * SEO defaults, theme. Works on every page, and follows the editor's typing in the studio preview.
 */
export function useSiteContent<T = Record<string, any>>(options: { initialData?: T } = {}): T {
  const { config } = useCmsContext();
  const globalPage = findGlobalPage(config);
  if (!globalPage) {
    throw new Error('[storio-editor] useSiteContent needs a page with global: true in the "pages" array of your CMS config.');
  }
  return usePageContent<T>(globalPage.key, options);
}
````

#### File 22 of 25: `<KIT_DIR>/site/CmsSection.tsx`

````tsx
'use client';

import React, { useState, useEffect, useMemo, useRef, useSyncExternalStore } from 'react';
import { createPortal } from 'react-dom';
import { PencilIcon } from './PencilIcon';
import { CMS_MESSAGE, listenForCmsMessages, postCmsMessage } from '../core/messages';
import { useCmsEditMode } from './preview';
import { useCmsContext } from './CmsProvider';
import { CmsSectionContext, EDIT_BUTTON_Z_INDEX, isFieldHoverActive, subscribeToFieldHover } from './sectionContext';

export interface CmsSectionProps {
  sectionKey: string;
  title: string;
  /**
   * Page this section's content belongs to. Set it to the key of your global page for
   * site-wide parts such as the navbar or footer, so they can be edited from every page.
   * Default: the page open in the studio (a global section is still found without it).
   */
  page?: string;
  /**
   * Optional pathname (for example "/") that this section belongs to.
   * Shared components such as a navbar render on every page, so without this
   * guard their edit button would appear on pages that do not own the section.
   */
  activeOnPath?: string;
  /**
   * Where the floating edit button sits. Use "fixed" for sticky headers and
   * banners whose own box is too small to hold the button.
   */
  buttonPlacement?: 'inside' | 'inside-low' | 'fixed';
  children: React.ReactNode;
}

/** Distance of the edit button from the top of the section (or of the window for "fixed"). */
const BUTTON_TOP: Record<NonNullable<CmsSectionProps['buttonPlacement']>, number> = {
  inside: 24,
  'inside-low': 112,
  fixed: 96,
};
const BUTTON_RIGHT = 32;
const WINDOW_MARGIN = 8;
const BUTTON_HEIGHT = 56;

/**
 * CmsSection
 *
 * In normal visitor mode: renders children directly with zero overhead.
 * In CMS edit mode (?cms_edit_mode=1 inside the studio preview):
 *  - Adds an outline and a floating edit button on hover.
 *  - Listens for SCROLL_TO_SECTION from the studio to centre and pulse the section.
 *  - Clicking anywhere on the section tells the studio to open this section's form.
 *
 * The button is rendered on document.body and only while its section is the innermost one
 * under the mouse, so sticky headers, nested sections and overlapping page content can
 * neither cover it nor catch its clicks.
 */
export const CmsSection: React.FC<CmsSectionProps> = ({
  sectionKey,
  title,
  page,
  activeOnPath,
  buttonPlacement = 'inside',
  children,
}) => {
  const { origins } = useCmsContext();
  const isEditMode = useCmsEditMode(origins);
  const [pathname, setPathname] = useState<string | null>(null);
  const [isTargeted, setIsTargeted] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [buttonPosition, setButtonPosition] = useState<{ top: number; right: number } | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLDivElement>(null);
  const originsKey = origins.join('|');

  useEffect(() => {
    setPathname(window.location.pathname);
  }, []);

  // A field's pencil takes priority, so only one pencil shows at a time.
  const isFieldActive = useSyncExternalStore(subscribeToFieldHover, isFieldHoverActive, () => false);
  const isSectionHovered = isHovered && !isFieldActive;

  const isValidPath = !activeOnPath || pathname === activeOnPath;
  const showButton = isEditMode && isValidPath && (isSectionHovered || isTargeted);
  const sectionContext = useMemo(
    () => ({ sectionKey, page, isEditMode: isEditMode && isValidPath, origins }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [sectionKey, page, isEditMode, isValidPath, originsKey]
  );

  // Listen for scroll commands from the studio
  useEffect(() => {
    if (!isEditMode) return;

    let timer: ReturnType<typeof setTimeout> | undefined;
    const unsubscribe = listenForCmsMessages(
      (message) => {
        if (message.type === CMS_MESSAGE.SCROLL_TO_SECTION && message.sectionKey === sectionKey) {
          if (sectionRef.current) {
            sectionRef.current.scrollIntoView({
              behavior: 'smooth',
              block: 'center',
            });
            setIsTargeted(true);
            clearTimeout(timer);
            timer = setTimeout(() => setIsTargeted(false), 2400);
          }
        }
      },
      { origins, source: () => window.parent }
    );

    return () => {
      clearTimeout(timer);
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEditMode, sectionKey, originsKey]);

  // Keep the button next to its section, and always inside the window
  useEffect(() => {
    if (!showButton) {
      setButtonPosition(null);
      return;
    }
    const update = () => {
      const section = sectionRef.current;
      if (!section) return;
      const rect = section.getBoundingClientRect();
      const isFixed = buttonPlacement === 'fixed' || rect.width === 0;
      const right = isFixed
        ? BUTTON_RIGHT
        : Math.max(WINDOW_MARGIN, document.documentElement.clientWidth - rect.right + BUTTON_RIGHT);
      const wanted = isFixed ? BUTTON_TOP[buttonPlacement] : rect.top + BUTTON_TOP[buttonPlacement];
      const lowest = Math.max(WINDOW_MARGIN, window.innerHeight - BUTTON_HEIGHT - WINDOW_MARGIN);
      const top = Math.min(Math.max(WINDOW_MARGIN, wanted), lowest);
      setButtonPosition((prev) => (prev && prev.top === top && prev.right === right ? prev : { top, right }));
    };
    update();
    window.addEventListener('scroll', update, true);
    window.addEventListener('resize', update);
    return () => {
      window.removeEventListener('scroll', update, true);
      window.removeEventListener('resize', update);
    };
  }, [showButton, buttonPlacement]);

  const handleEditClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (typeof window !== 'undefined' && window.parent && window.parent !== window) {
      postCmsMessage(
        window.parent,
        {
          type: CMS_MESSAGE.EDIT_SECTION,
          sectionKey,
          ...(page ? { page } : {}),
          title,
        },
        origins
      );
    }
  };

  // Only the innermost section under the mouse is active, and a field's own pencil takes priority.
  const handleMouseOver = (e: React.MouseEvent) => {
    const target = e.target as Element;
    if (buttonRef.current?.contains(target)) return;
    setIsHovered(!target.closest('[data-cms-field]') && target.closest('[data-cms-section]') === sectionRef.current);
  };

  // Zero wrapper overhead for normal visitors
  if (!isEditMode || !isValidPath) {
    return <CmsSectionContext.Provider value={sectionContext}>{children}</CmsSectionContext.Provider>;
  }

  return (
    <div
      ref={sectionRef}
      data-cms-section={sectionKey}
      onClick={handleEditClick}
      onMouseOver={handleMouseOver}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        // Inline styles, so the outline works in any template (no CSS framework needed).
        position: 'relative',
        cursor: 'pointer',
        borderRadius: 16,
        transition: 'box-shadow 0.3s',
        boxShadow: isTargeted
          ? '0 0 0 4px #020617, 0 0 0 8px #a855f7, 0 0 60px rgba(168, 85, 247, 0.5)'
          : isSectionHovered
          ? '0 0 0 2px #0f172a, 0 0 0 4px #a855f7'
          : undefined,
      }}
    >
      <CmsSectionContext.Provider value={sectionContext}>{children}</CmsSectionContext.Provider>

      {/* Floating edit button, rendered above the whole page */}
      {showButton &&
        buttonPosition &&
        createPortal(
          <div
            ref={buttonRef}
            data-cms-edit-button={sectionKey}
            style={{ position: 'fixed', top: buttonPosition.top, right: buttonPosition.right, zIndex: EDIT_BUTTON_Z_INDEX }}
          >
            <button
              type="button"
              onClick={handleEditClick}
              title={`Edit ${title} in the editor panel`}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '10px 20px',
                borderRadius: 16,
                background: '#9333ea',
                color: '#ffffff',
                fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif',
                fontWeight: 800,
                fontSize: 14,
                lineHeight: '20px',
                letterSpacing: '0.025em',
                whiteSpace: 'nowrap',
                border: '2px solid rgba(216, 180, 254, 0.8)',
                boxShadow: '0 25px 50px -12px rgba(59, 7, 100, 0.8)',
                cursor: 'pointer',
              }}
            >
              <PencilIcon size={16} color="#f3e8ff" />
              <span>Edit {title}</span>
            </button>
          </div>,
          document.body
        )}
    </div>
  );
};
````

#### File 23 of 25: `<KIT_DIR>/site/CmsField.tsx`

````tsx
'use client';

import React, { useCallback, useContext, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { PencilIcon } from './PencilIcon';
import { CMS_MESSAGE, EDIT_MODE_PARAM, postCmsMessage } from '../core/messages';
import { getAtPath, parseFieldPath } from '../core/paths';
import { CmsSectionContext, EDIT_BUTTON_Z_INDEX, claimFieldHover, releaseFieldHover } from './sectionContext';
import { useCmsContext } from './CmsProvider';
import { useCmsEditMode } from './preview';
import { useItemDraft } from './itemDrafts';
import { INLINE_TAGS, fieldStyleFonts, fieldStyleToCss, fontStylesheetUrl, hasFieldStyle, resolveFieldPage, styleId } from '../core/styles';
import { useStoredFieldStyle } from './fieldStyles';

export interface CmsFieldProps {
  /**
   * Where the value lives, in dot form: "title", "image", "items.0.title". Inside a section it is
   * a path in the section's content; with `collection` it is a field of the record. It can also
   * point to a whole object or list ("items.0").
   */
  path: string;
  /** Name shown on the pencil button. Default: made from the path. */
  label?: string;
  /**
   * Edit a field of a collection record (a blog post, a product...) instead of section content.
   * Use the collection key of the page, e.g. "blog", together with `item`.
   */
  collection?: string;
  /** The record's id, the same id your collection handler's `get` and `save` receive. */
  item?: string | number;
  /**
   * Edit a value of another section than the surrounding one, or a value shown outside any
   * <CmsSection>: for example the site phone number from the global page inside the contact page.
   * Use with `page` (the global page's key) when the section is not on the open page.
   */
  section?: string;
  /** Page of `section`. Default: the surrounding section's page, else the open page. */
  page?: string;
  children: React.ReactNode;
}

interface Box {
  top: number;
  left: number;
  width: number;
  height: number;
}

const PENCIL_SIZE = 30;
const WINDOW_MARGIN = 4;
/** How long the pencil stays after the mouse leaves, so it can still be reached. */
const HIDE_DELAY_MS = 400;

function labelFromPath(path: string): string {
  const name = path.split('.').filter((part) => !/^\d+$/.test(part)).pop() ?? path;
  const words = name.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ');
  return words.charAt(0).toUpperCase() + words.slice(1);
}

interface FieldFrameProps {
  path: string;
  name: string;
  isEditMode: boolean;
  onOpen: (kind: 'image' | 'icon' | 'text') => void;
  children: React.ReactNode;
}

/**
 * What the field shows, so the studio offers the matching styles: "image" (a picture and no text),
 * "icon" (only an <svg> and no text) or "text".
 */
function fieldKindOf(wrapper: HTMLElement | null): 'image' | 'icon' | 'text' {
  if (!wrapper) return 'text';
  const media = wrapper.querySelector('img, picture, video, svg, canvas');
  if (!media) return 'text';
  // Visible text only: a styled field has its own <style> element inside, whose CSS is not text.
  const copy = wrapper.cloneNode(true) as HTMLElement;
  copy.querySelectorAll('style, script, noscript, link').forEach((node) => node.remove());
  if ((copy.textContent ?? '').trim()) return 'text';
  return copy.querySelector('img, picture, video, canvas') ? 'image' : 'icon';
}

/** The hover outline and pencil shared by section fields and record fields. */
const FieldFrame: React.FC<FieldFrameProps> = ({ path, name, isEditMode, onOpen, children }) => {
  const wrapperRef = useRef<HTMLSpanElement>(null);
  const pencilRef = useRef<HTMLButtonElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [box, setBox] = useState<Box | null>(null);
  const showControls = isEditMode && isHovered;
  const hideTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const hideNow: () => void = useCallback(() => {
    clearTimeout(hideTimer.current);
    setIsHovered(false);
    releaseFieldHover(hideNow);
  }, []);

  const show = () => {
    clearTimeout(hideTimer.current);
    claimFieldHover(hideNow);
    setIsHovered(true);
  };

  const hideSoon = () => {
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(hideNow, HIDE_DELAY_MS);
  };

  useEffect(
    () => () => {
      clearTimeout(hideTimer.current);
      releaseFieldHover(hideNow);
    },
    [hideNow]
  );

  // Follow the field while the mouse is on it, including content that moves by itself.
  useEffect(() => {
    if (!showControls) {
      setBox(null);
      return;
    }
    let frame = 0;
    const range = document.createRange();
    const measure = () => {
      const wrapper = wrapperRef.current;
      // Hold the pencil still while the mouse is on it, so moving content stays clickable.
      if (wrapper && !pencilRef.current?.matches(':hover')) {
        range.selectNodeContents(wrapper);
        const rect = range.getBoundingClientRect();
        setBox((prev) =>
          prev && prev.top === rect.top && prev.left === rect.left && prev.width === rect.width && prev.height === rect.height
            ? prev
            : { top: rect.top, left: rect.left, width: rect.width, height: rect.height }
        );
      }
      frame = requestAnimationFrame(measure);
    };
    measure();
    return () => cancelAnimationFrame(frame);
  }, [showControls]);

  if (!isEditMode) return <>{children}</>;

  const open = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (window.parent === window) return;
    onOpen(fieldKindOf(wrapperRef.current));
  };

  // Only the innermost field under the mouse is active.
  const handleMouseOver = (e: React.MouseEvent) => {
    const target = e.target as Element;
    if (pencilRef.current?.contains(target) || target.closest('[data-cms-field]') === wrapperRef.current) show();
    else hideNow();
  };

  const pencilTop = box
    ? Math.min(Math.max(WINDOW_MARGIN, box.top - PENCIL_SIZE / 2), window.innerHeight - PENCIL_SIZE - WINDOW_MARGIN)
    : 0;
  const pencilLeft = box
    ? Math.min(
        Math.max(WINDOW_MARGIN, box.left + box.width - PENCIL_SIZE / 2),
        document.documentElement.clientWidth - PENCIL_SIZE - WINDOW_MARGIN
      )
    : 0;

  return (
    <span
      ref={wrapperRef}
      data-cms-field={path}
      style={{ display: 'contents' }}
      onClick={open}
      onMouseOver={handleMouseOver}
      onMouseLeave={hideSoon}
    >
      {children}
      {showControls &&
        box &&
        createPortal(
          <>
            <div
              aria-hidden="true"
              style={{
                position: 'fixed',
                top: box.top - 3,
                left: box.left - 3,
                width: box.width + 6,
                height: box.height + 6,
                border: '2px solid #a855f7',
                borderRadius: 6,
                pointerEvents: 'none',
                boxSizing: 'border-box',
                zIndex: EDIT_BUTTON_Z_INDEX,
              }}
            />
            <button
              ref={pencilRef}
              type="button"
              data-cms-field-button={path}
              onClick={open}
              title={`Edit ${name}`}
              aria-label={`Edit ${name}`}
              style={{
                position: 'fixed',
                top: pencilTop,
                left: pencilLeft,
                width: PENCIL_SIZE,
                height: PENCIL_SIZE,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: 0,
                color: '#ffffff',
                background: '#9333ea',
                border: '2px solid #e9d5ff',
                borderRadius: 9999,
                boxShadow: '0 4px 14px rgba(59, 7, 100, 0.55)',
                cursor: 'pointer',
                zIndex: EDIT_BUTTON_Z_INDEX + 1,
              }}
            >
              <PencilIcon size={14} />
            </button>
          </>,
          document.body
        )}
    </span>
  );
};

/**
 * The page a field's styles belong to. Without a page prop and with a section key used on several
 * pages, the URL decides after mount (so styles of that field appear after hydration).
 */
function useFieldPage(section: string, explicitPage: string | undefined, isEditMode: boolean): string | undefined {
  const { config } = useCmsContext();
  const direct = resolveFieldPage(config, section, explicitPage);
  const [pathname, setPathname] = useState<string | undefined>(undefined);
  useEffect(() => {
    if (!direct) setPathname(window.location.pathname);
  }, [direct]);
  const page = direct ?? resolveFieldPage(config, section, undefined, pathname);
  useEffect(() => {
    if (isEditMode && !direct && pathname !== undefined && config.pages.filter((p) => p.sections.some((s) => s.key === section)).length > 1) {
      console.info(`[storio-editor] Section "${section}" is on several pages. Add page="<page key>" to its <CmsSection> so field styles render on the server.`);
    }
  }, [isEditMode, direct, pathname, section, config.pages]);
  return page;
}

/**
 * Applies the field's saved (or unsaved, in the studio) style: marks the element with
 * data-cms-style and writes its CSS in a <style> just before it. A single plain HTML element child
 * gets the attribute itself; anything else is wrapped in a <span>, only when there is a style.
 */
const StyledField: React.FC<{ page: string | undefined; section: string; path: string; children: React.ReactNode }> = ({
  page,
  section,
  path,
  children,
}) => {
  const { styles, config } = useCmsContext();
  const style = useStoredFieldStyle(styles, page, section, path);
  if (!page || !hasFieldStyle(style)) return <>{children}</>;
  const id = styleId(page, section, path);
  const items = React.Children.toArray(children);
  const only = items.length === 1 ? items[0] : null;
  const canMark = React.isValidElement(only) && typeof only.type === 'string';
  const marked = canMark
    ? React.cloneElement(only as React.ReactElement<Record<string, unknown>>, { 'data-cms-style': id })
    : <span data-cms-style={id}>{children}</span>;
  const inline = canMark && INLINE_TAGS.has(String((only as React.ReactElement).type));
  const css = fieldStyleToCss(id, style, { breakpoints: config.styles?.breakpoints, wrapper: !canMark, inline });
  // A font chosen in the Style tab must be loaded, or the browser falls back to another one.
  const fontUrls = fieldStyleFonts(style).map(fontStylesheetUrl).filter((url): url is string => !!url);
  return (
    <>
      {fontUrls.map((url) => (
        <link key={url} rel="stylesheet" href={url} />
      ))}
      {css && <style data-cms-style-for={id} dangerouslySetInnerHTML={{ __html: css }} />}
      {marked}
    </>
  );
};

const SectionField: React.FC<Omit<CmsFieldProps, 'collection' | 'item'>> = ({ path, label, section: sectionProp, page, children }) => {
  const surrounding = useContext(CmsSectionContext);
  const name = label ?? labelFromPath(path);

  useEffect(() => {
    if (!surrounding && !sectionProp && new URLSearchParams(window.location.search).has(EDIT_MODE_PARAM)) {
      console.warn(`[storio-editor] <CmsField path="${path}"> must be placed inside a <CmsSection>, or given collection and item.`);
    }
  }, [surrounding, sectionProp, path]);

  if (sectionProp) {
    return (
      <OtherSectionField path={path} name={name} sectionKey={sectionProp} page={page}>
        {children}
      </OtherSectionField>
    );
  }
  if (!surrounding) return <>{children}</>;
  const targetPage = page ?? surrounding.page;
  return (
    <SurroundedField path={path} name={name} sectionKey={surrounding.sectionKey} page={targetPage} isEditMode={surrounding.isEditMode} origins={surrounding.origins}>
      {children}
    </SurroundedField>
  );
};

/** A field inside its <CmsSection>. */
const SurroundedField: React.FC<{
  path: string;
  name: string;
  sectionKey: string;
  page?: string;
  isEditMode: boolean;
  origins: string[];
  children: React.ReactNode;
}> = ({ path, name, sectionKey, page: targetPage, isEditMode, origins, children }) => {
  const stylePage = useFieldPage(sectionKey, targetPage, isEditMode);
  return (
    <FieldFrame
      path={path}
      name={name}
      isEditMode={isEditMode}
      onOpen={(fieldKind) =>
        postCmsMessage(
          window.parent,
          {
            type: CMS_MESSAGE.EDIT_SECTION,
            sectionKey,
            ...(targetPage ? { page: targetPage } : {}),
            title: name,
            fieldPath: path,
            fieldKind,
          },
          origins
        )
      }
    >
      <StyledField page={stylePage} section={sectionKey} path={path}>
        {children}
      </StyledField>
    </FieldFrame>
  );
};

/** A field that names its own section, so it works outside (or inside another) <CmsSection>. */
const OtherSectionField: React.FC<{ path: string; name: string; sectionKey: string; page?: string; children: React.ReactNode }> = ({
  path,
  name,
  sectionKey,
  page,
  children,
}) => {
  const { origins } = useCmsContext();
  const isEditMode = useCmsEditMode(origins);
  const stylePage = useFieldPage(sectionKey, page, isEditMode);
  return (
    <FieldFrame
      path={path}
      name={name}
      isEditMode={isEditMode}
      onOpen={(fieldKind) =>
        postCmsMessage(
          window.parent,
          { type: CMS_MESSAGE.EDIT_SECTION, sectionKey, ...(page ? { page } : {}), title: name, fieldPath: path, fieldKind },
          origins
        )
      }
    >
      <StyledField page={stylePage} section={sectionKey} path={path}>
        {children}
      </StyledField>
    </FieldFrame>
  );
};

const RecordField: React.FC<Omit<CmsFieldProps, 'item'> & { collection: string; item: string }> = ({
  path,
  label,
  collection,
  item,
  children,
}) => {
  const { origins } = useCmsContext();
  const isEditMode = useCmsEditMode(origins);
  const draft = useItemDraft(collection, item);
  const name = label ?? labelFromPath(path);

  // Plain text children follow the editor's typing; other content updates after saving.
  let content = children;
  if (draft && (typeof children === 'string' || typeof children === 'number')) {
    const value = getAtPath(draft, parseFieldPath(path));
    if (typeof value === 'string' || typeof value === 'number') content = value;
  }

  return (
    <FieldFrame
      path={path}
      name={name}
      isEditMode={isEditMode}
      onOpen={() =>
        postCmsMessage(
          window.parent,
          { type: CMS_MESSAGE.EDIT_SECTION, sectionKey: '', title: name, fieldPath: path, collection, item },
          origins
        )
      }
    >
      {content}
    </FieldFrame>
  );
};

/**
 * CmsField
 *
 * Gives one value its own pencil, so an editor can change just the title, the image or the icon.
 * Place it inside a <CmsSection> for page content, or give it `collection` and `item` to edit a
 * field of a database record (a blog post, a product) on a [slug] or [id] page.
 *
 * Visitors get the children only, with no extra element. In the studio preview the wrapper uses
 * `display: contents`, so it does not affect the page layout.
 */
export const CmsField: React.FC<CmsFieldProps> = ({ collection, item, ...props }) => {
  if (collection && item !== undefined && item !== null && item !== '') {
    return <RecordField {...props} collection={collection} item={String(item)} />;
  }
  return <SectionField {...props} />;
};
````

#### File 24 of 25: `<KIT_DIR>/site/CmsIcon.tsx`

````tsx
'use client';

import React from 'react';
import type { IconComponent } from '../core/types';
import { useCmsConfig } from './CmsProvider';

export interface CmsIconProps {
  /** Icon name saved in the content, a key of `icons` in your CMS config. */
  name: string | undefined;
  /** Drawn when the name is not in `icons`. Default: nothing. */
  fallback?: IconComponent;
  className?: string;
  [prop: string]: unknown;
}

const warned = new Set<string>();

/**
 * Draws an editable icon by name from the `icons` map of your CMS config, the same list
 * the icon picker offers, so an icon picked in the editor always shows on the site.
 */
export const CmsIcon: React.FC<CmsIconProps> = ({ name, fallback, ...props }) => {
  const icons = useCmsConfig().icons;
  const Icon = (name && icons?.[name]) || fallback;
  if (!Icon) {
    if (name && !warned.has(name)) {
      warned.add(name);
      console.warn(
        icons
          ? `[storio-editor] <CmsIcon name="${name}">: "${name}" is not in the icons of your CMS config.`
          : '[storio-editor] <CmsIcon> needs an `icons` map in defineCms({ ... }).'
      );
    }
    return null;
  }
  const Component = Icon as React.ComponentType<Record<string, unknown>>;
  return <Component aria-hidden="true" {...props} />;
};
````

#### File 25 of 25: `<KIT_DIR>/site/CmsThemeStyle.tsx`

````tsx
'use client';

import React from 'react';
import { themeToCss } from '../core/theme';
import { useSiteContent } from './CmsProvider';

export interface CmsThemeStyleProps {
  /** Section of the global page that holds the theme. Default: "theme". */
  section?: string;
  /** Start of every variable name. Default: "--", so primaryColor becomes --primary-color. */
  prefix?: string;
  /** Where the variables apply. Default: ":root". */
  selector?: string;
}

/**
 * Writes the theme section of the global page as CSS variables, for example
 * `:root{--primary-color:#7c3aed;--heading-font:Inter;}`. Put it once in the root layout, inside
 * <CmsProvider>, and use the variables in your CSS. Colour changes show in the studio preview as
 * the editor picks them.
 */
export const CmsThemeStyle: React.FC<CmsThemeStyleProps> = ({ section = 'theme', prefix, selector }) => {
  const site = useSiteContent<Record<string, unknown>>();
  const css = themeToCss(site[section], { prefix, selector });
  if (!css) return null;
  return <style data-cms-theme={section} dangerouslySetInnerHTML={{ __html: css }} />;
};
````

---

## For the reviewer (after Claude Code is done)

- [ ] `git diff` shows no change to the SDK fetchers, the customization handling, the classic customizer's postMessage code, or the manifest's `customization`/`navigation`.
- [ ] `<KIT_DIR>` has all 25 files of Appendix A, unchanged; nothing imports `@brainicon/storio-elements-editor`.
- [ ] `public/storio.template.json` has `"editor": "storio-elements"` and `editorPages`; every key starts with the template id; no page is global.
- [ ] `npm run editor:check`, `npx tsc --noEmit` and `npm run build` pass.
- [ ] The site looks exactly the same for visitors.
- [ ] In the dashboard: pencils on the converted content, live typing, drafts stay private, publish changes the live site, styles work.

## Changing default texts later

Edit `CONFIG_DIR/content/<page key>.json`, run `npm run editor:sync` (it updates the manifest; `npm run build` refuses to build while the two differ), then increase the version, publish and get it approved. A school that already edited a section keeps its own values for the fields it saved; new fields show their defaults (the `use<Page>Text` helper fills them in).
